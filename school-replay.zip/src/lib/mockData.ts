/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User, ScheduleItem, ReplayNote, HomeworkTask, QuestItem, AppNotification } from '../types';

export const INITIAL_USER: User = {
  id: 'user_1',
  name: 'นรวิชญ์ ศักดิ์ดีเลิศ',
  email: 'norawit.sak@student.mail.go.th',
  avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&h=150',
  grade: 'ม.5',
  classroom: '5/4',
  level: 3,
  xp: 320,
  xpNeeded: 500,
  streak: 5,
  totalSubmittedTasks: 18,
  questScore: 240
};

export const INITIAL_SCHEDULE: ScheduleItem[] = [
  // จันทร์
  {
    id: 's_mon_1',
    day: 'จันทร์',
    period: 1,
    subject: 'คณิตศาสตร์เพิ่มเติม',
    teacher: 'ครูสมปอง สุขสำราญ',
    timeStart: '08:30',
    timeEnd: '09:20',
    classroom: 'ห้องเรียน 421',
    color: '#3b82f6' // Blue
  },
  {
    id: 's_mon_2',
    day: 'จันทร์',
    period: 2,
    subject: 'คณิตศาสตร์เพิ่มเติม',
    teacher: 'ครูสมปอง สุขสำราญ',
    timeStart: '09:20',
    timeEnd: '10:10',
    classroom: 'ห้องเรียน 421',
    color: '#3b82f6' // Blue
  },
  {
    id: 's_mon_3',
    day: 'จันทร์',
    period: 3,
    subject: 'ฟิสิกส์ 3',
    teacher: 'ครูอัจฉรา วิริยะ',
    timeStart: '10:10',
    timeEnd: '11:00',
    classroom: 'ห้องแล็บฟิสิกส์ 1',
    color: '#0ea5e9' // Sky Blue
  },
  {
    id: 's_mon_4',
    day: 'จันทร์',
    period: 4,
    subject: 'ฟิสิกส์ 3',
    teacher: 'ครูอัจฉรา วิริยะ',
    timeStart: '11:00',
    timeEnd: '11:50',
    classroom: 'ห้องแล็บฟิสิกส์ 1',
    color: '#0ea5e9' // Sky Blue
  },
  {
    id: 's_mon_5',
    day: 'จันทร์',
    period: 5,
    subject: 'ภาษาอังกฤษอ่านเขียน',
    teacher: 'T. Robert Smith',
    timeStart: '12:40',
    timeEnd: '13:30',
    classroom: 'ห้องอาเซียน 2',
    color: '#8b5cf6' // Purple
  },
  {
    id: 's_mon_6',
    day: 'จันทร์',
    period: 6,
    subject: 'ภาษาไทย 3',
    teacher: 'ครูวรรณวิภา สายสวรรค์',
    timeStart: '13:30',
    timeEnd: '14:20',
    classroom: 'ห้องเรียน 542',
    color: '#f59e0b' // Orange
  },
  {
    id: 's_mon_7',
    day: 'จันทร์',
    period: 7,
    subject: 'แนะแนว',
    teacher: 'ครูดาริกา โสภณ',
    timeStart: '14:20',
    timeEnd: '15:10',
    classroom: 'ห้องแนะแนว',
    color: '#10b981' // Green
  },

  // อังคาร
  {
    id: 's_tue_1',
    day: 'อังคาร',
    period: 1,
    subject: 'ชีววิทยา 3',
    teacher: 'ครูสุพรรณนา แก้วดี',
    timeStart: '08:30',
    timeEnd: '09:20',
    classroom: 'ห้องแล็บชีวะ 2',
    color: '#ec4899' // Pink
  },
  {
    id: 's_tue_2',
    day: 'อังคาร',
    period: 2,
    subject: 'ชีววิทยา 3',
    teacher: 'ครูสุพรรณนา แก้วดี',
    timeStart: '09:20',
    timeEnd: '10:10',
    classroom: 'ห้องแล็บชีวะ 2',
    color: '#ec4899' // Pink
  },
  {
    id: 's_tue_3',
    day: 'อังคาร',
    period: 3,
    subject: 'เคมี 3',
    teacher: 'ครูประภาส อนันต์',
    timeStart: '10:10',
    timeEnd: '11:00',
    classroom: 'ห้องเคมี 404',
    color: '#14b8a6' // Teal
  },
  {
    id: 's_tue_4',
    day: 'อังคาร',
    period: 4,
    subject: 'เคมี 3',
    teacher: 'ครูประภาส อนันต์',
    timeStart: '11:00',
    timeEnd: '11:50',
    classroom: 'ห้องเคมี 404',
    color: '#14b8a6' // Teal
  },
  {
    id: 's_tue_5',
    day: 'อังคาร',
    period: 5,
    subject: 'ศิลปศึกษา (ดนตรีสากล)',
    teacher: 'ครูเทวฤทธิ์ ภิรมย์',
    timeStart: '12:40',
    timeEnd: '13:30',
    classroom: 'ห้องดนตรี',
    color: '#eab308' // Yellow
  },
  {
    id: 's_tue_6',
    day: 'อังคาร',
    period: 6,
    subject: 'สังคมศึกษาพื้นฐาน',
    teacher: 'ครูพิชญุตม์ มีธรรม',
    timeStart: '13:30',
    timeEnd: '14:20',
    classroom: 'ห้องสังคม 324',
    color: '#f97316' // Orange-Red
  },
  {
    id: 's_tue_7',
    day: 'อังคาร',
    period: 7,
    subject: 'เทคโนโลยี (วิทยาการคำนวณ)',
    teacher: 'ครูประภาพร รักไอที',
    timeStart: '14:20',
    timeEnd: '15:10',
    classroom: 'ห้องคอมพิวเตอร์ 3',
    color: '#6366f1' // Indigo
  }
];

export const INITIAL_NOTES: ReplayNote[] = [
  {
    id: 'note_1',
    date: '2026-05-22',
    subject: 'ชีววิทยา 3',
    topic: 'สังเคราะห์ด้วยแสงและโครมาโทกราฟี',
    content: 'ศึกษาเรื่องการดูดกลืนแสงของรงควัตถุชนิดต่างๆ ในใบไม้ โดยทำปฏิบัติการสกัดจากผักโขมแล้วแยกด้วยโครมาโทกราฟีกระดาษ พบว่ามีคลอโรฟิลล์ เอ (สีเขียวเข้ม), คลอโรฟิลล์ บี (สีเขียวอมเหลือง), คาโรทีนอยด์ (สีส้ม/เหลือง)',
    homework: 'เขียนรายงานสรุปผลการทำการทดลองชีววิทยา 3',
    dueDate: '2026-05-24',
    imageUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=600&auto=format&fit=crop'
  },
  {
    id: 'note_2',
    date: '2026-05-21',
    subject: 'เคมี 3',
    topic: 'พันธะเคมีและสมบัติของตะกอนสารประกอบไอออนิก',
    content: 'ทดลองการละลายและการเกิดตะกอนของคู่ไอออนต่างๆ โซเดียมคาร์บอเนตทำปฏิกิริยากับแคลเซียมคลอไรด์เกิดตะกอนสีขาวขุ่นของแคลเซียมคาร์บอเนต การบ้านคือดุลสมการไอออนิกสุทธิ 5 ข้อ',
    homework: 'ทำแบบฝึกหัดแก้โจทย์สมการไอออนิก หน้า 44 ข้อ 1-5',
    dueDate: '2026-05-26',
    imageUrl: 'https://images.unsplash.com/photo-1603126857599-f6e157fa2fe6?q=80&w=600&auto=format&fit=crop'
  }
];

export const INITIAL_TASKS: HomeworkTask[] = [
  {
    id: 'task_1',
    title: 'รายงานชีววิทยา: สรุปโครมาโทกราฟีกระดาษ',
    subject: 'ชีววิทยา 3',
    dueDate: '2026-05-24', // พรุ่งนี้ (Relative to May 23)
    status: 'near_due',
    xpReward: 100,
    noteId: 'note_1'
  },
  {
    id: 'task_2',
    title: 'โจทย์สมการเคมีไอออนิก หน้า 44 ข้อ 1-5',
    subject: 'เคมี 3',
    dueDate: '2026-05-26',
    status: 'todo',
    xpReward: 80,
    noteId: 'note_2'
  },
  {
    id: 'task_3',
    title: 'แปลบทความภาษาอังกฤษวิทยาศาสตร์ 2 หน้า',
    subject: 'ภาษาอังกฤษอ่านเขียน',
    dueDate: '2026-05-29',
    status: 'todo',
    xpReward: 90
  },
  {
    id: 'task_4',
    title: 'ทำความเข้าใจทบทวนโครงสร้างบทกวีนิราศภูเขาทอง',
    subject: 'ภาษาไทย 3',
    dueDate: '2026-05-21',
    status: 'done',
    xpReward: 50
  }
];

export const INITIAL_QUESTS: QuestItem[] = [
  {
    id: 'quest_1',
    title: 'จดสรุป Replay Notes 3 คาบ',
    targetQuantity: 3,
    currentQuantity: 2,
    completed: false,
    xpReward: 150,
    isDaily: true,
    type: 'notes'
  },
  {
    id: 'quest_2',
    title: 'ส่งงาน/การบ้านให้ครบทุกวิชาในสัปดาห์นี้',
    targetQuantity: 1,
    currentQuantity: 1,
    completed: true,
    xpReward: 200,
    isDaily: false,
    type: 'tasks'
  },
  {
    id: 'quest_3',
    title: 'เช็กอินเข้าใช้งาน School Replay ต่อเนื่อง 5 วัน',
    targetQuantity: 5,
    currentQuantity: 5,
    completed: true,
    xpReward: 100,
    isDaily: true,
    type: 'streak'
  },
  {
    id: 'quest_4',
    title: 'เคลียร์ภารกิจการบ้านวันนี้ 1 รายการ',
    targetQuantity: 1,
    currentQuantity: 0,
    completed: false,
    xpReward: 80,
    isDaily: true,
    type: 'tasks'
  }
];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif_1',
    title: 'แจ้งเตือนก่อนเข้าเรียน 10 นาที',
    message: 'คาบถัดไปวิชา “ชีววิทยา 3” จะเริ่มในเวลา 08:30 น. เตรียมสมุดและปากกาไว้พร้อมกันเลย!',
    type: 'class_alert',
    time: '08:20 น.',
    read: false
  },
  {
    id: 'notif_2',
    title: 'แจ้งเตือนงานด่วนใกล้เดดไลน์',
    message: '“รายงานชีววิทยา” ของคุณมีกำหนดส่งพรุ่งนี้แล้ว อย่าลืมส่งจดสรุปและตรวจความเรียบร้อยล่ะ!',
    type: 'task_alert',
    time: 'เมื่อ 2 ชั่วโมงก่อน',
    read: false
  },
  {
    id: 'notif_3',
    title: 'แจ้งเตือนสรุปประจำวัน',
    message: 'หมดชั่วโมงเรียนแล้ว! คุณสามารถกดปุ่ม “สรุปวันนี้” เพื่อสร้างบทสรุปภาพรวมการเรียนและส่งความภูมิใจให้ตัวเอง',
    type: 'summary_alert',
    time: '15:15 น.',
    read: true
  }
];

// Helper to load/save state
export const loadStorage = <T>(key: string, defaultValue: T): T => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.error('Error loading state from localStorage:', error);
    return defaultValue;
  }
};

export const saveStorage = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('Error saving state to localStorage', error);
  }
};
