/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  grade: string; // เช่น ม.5
  classroom: string; // เช่น 5/1
  level: number;
  xp: number;
  xpNeeded: number;
  streak: number;
  totalSubmittedTasks: number;
  questScore: number;
}

export interface ScheduleItem {
  id: string;
  day: string; // 'จันทร์' | 'อังคาร' | 'พุธ' | 'พฤหัสบดี' | 'ศุกร์'
  period: number; // 1 - 7
  subject: string;
  teacher: string;
  timeStart: string; // HH:MM
  timeEnd: string; // HH:MM
  classroom: string;
  color: string; // Tailwind hex or class name
}

export interface ReplayNote {
  id: string;
  date: string; // YYYY-MM-DD
  subject: string;
  topic: string; // วันนี้เรียนอะไร
  content: string; // บันทึกรายละเอียด
  homework?: string; // การบ้าน
  dueDate?: string; // วันส่งการบ้าน
  imageUrl?: string; // แนบรูป (Mock URL)
}

export interface HomeworkTask {
  id: string;
  title: string;
  subject: string;
  dueDate: string; // YYYY-MM-DD
  status: 'todo' | 'near_due' | 'done'; // ต้องทำ | ใกล้ส่ง | ส่งแล้ว
  xpReward: number;
  noteId?: string;
}

export interface QuestItem {
  id: string;
  title: string;
  targetQuantity: number;
  currentQuantity: number;
  completed: boolean;
  xpReward: number;
  isDaily: boolean;
  type: 'notes' | 'tasks' | 'streak';
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'class_alert' | 'task_alert' | 'summary_alert' | 'general';
  time: string;
  read: boolean;
}
