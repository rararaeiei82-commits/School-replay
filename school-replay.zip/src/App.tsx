/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { 
  User, ScheduleItem, ReplayNote, HomeworkTask, QuestItem, AppNotification 
} from './types';
import {
  INITIAL_USER, INITIAL_SCHEDULE, INITIAL_NOTES, INITIAL_TASKS,
  INITIAL_QUESTS, INITIAL_NOTIFICATIONS, loadStorage, saveStorage
} from './lib/mockData';

// Component Imports
import LandingPage from './components/LandingPage';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import ScheduleView from './components/ScheduleView';
import ReplayNotes from './components/ReplayNotes';
import TasksView from './components/TasksView';
import QuestView from './components/QuestView';
import ProfileView from './components/ProfileView';
import NotificationPanel from './components/NotificationPanel';
import DailySummaryModal from './components/DailySummaryModal';

// Icons for nav
import { 
  LayoutDashboard, Calendar, BookOpen, CheckSquare, Trophy, User as UserIcon, Bell, Sparkles, GraduationCap 
} from 'lucide-react';

export default function App() {
  // Navigation & Authentication states
  const [step, setStep] = useState<'landing' | 'login' | 'app'>('landing');
  const [currentTab, setCurrentTab] = useState('dashboard');
  
  // Custom interactive simulator hour (starts at school time e.g., 09:40)
  const [simHour, setSimHour] = useState(9);
  const [simMinute, setSimMinute] = useState(40);

  // App Database states (loaded from localStorage with mock defaults)
  const [user, setUser] = useState<User>(INITIAL_USER);
  const [schedules, setSchedules] = useState<ScheduleItem[]>([]);
  const [notes, setNotes] = useState<ReplayNote[]>([]);
  const [tasks, setTasks] = useState<HomeworkTask[]>([]);
  const [quests, setQuests] = useState<QuestItem[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  // UI State toggles
  const [showNotifPanel, setShowNotifPanel] = useState(false);
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const [levelUpToast, setLevelUpToast] = useState<string | null>(null);
  const [xpToast, setXpToast] = useState<number | null>(null);

  // Initial Sync from persist storage
  useEffect(() => {
    setSchedules(loadStorage<ScheduleItem[]>('sr_schedules', INITIAL_SCHEDULE));
    setNotes(loadStorage<ReplayNote[]>('sr_notes', INITIAL_NOTES));
    setTasks(loadStorage<HomeworkTask[]>('sr_tasks', INITIAL_TASKS));
    setQuests(loadStorage<QuestItem[]>('sr_quests', INITIAL_QUESTS));
    setNotifications(loadStorage<AppNotification[]>('sr_notifications', INITIAL_NOTIFICATIONS));
    
    const savedUser = localStorage.getItem('sr_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
      setStep('app'); // Auto-login if session exists
    }
  }, []);

  // Sync state helpers
  const saveUserState = (updatedUser: User) => {
    setUser(updatedUser);
    localStorage.setItem('sr_user', JSON.stringify(updatedUser));
  };

  const saveSchedulesState = (updated: ScheduleItem[]) => {
    setSchedules(updated);
    saveStorage('sr_schedules', updated);
  };

  const saveNotesState = (updated: ReplayNote[]) => {
    setNotes(updated);
    saveStorage('sr_notes', updated);
  };

  const saveTasksState = (updated: HomeworkTask[]) => {
    setTasks(updated);
    saveStorage('sr_tasks', updated);
  };

  const saveQuestsState = (updated: QuestItem[]) => {
    setQuests(updated);
    saveStorage('sr_quests', updated);
  };

  const saveNotificationsState = (updated: AppNotification[]) => {
    setNotifications(updated);
    saveStorage('sr_notifications', updated);
  };

  // XP addition utility with level up triggers
  const addXp = (amount: number, currentUser: User) => {
    let currentXp = currentUser.xp + amount;
    let currentLevel = currentUser.level;
    let needed = currentUser.xpNeeded;
    let score = currentUser.questScore + Math.round(amount / 2);

    let isLeveledUp = false;

    if (currentXp >= needed) {
      currentXp -= needed;
      currentLevel += 1;
      needed = Math.round(needed * 1.3);
      isLeveledUp = true;
    }

    const updated: User = {
      ...currentUser,
      xp: currentXp,
      level: currentLevel,
      xpNeeded: needed,
      questScore: score
    };

    saveUserState(updated);
    
    // Trigger Level Up custom HUD indicator
    if (isLeveledUp) {
      setLevelUpToast(`🎉 ยินดีด้วย เลเวลอัปเป็น Level ${currentLevel} แล้ว!`);
      setTimeout(() => setLevelUpToast(null), 4000);
    } else {
      setXpToast(amount);
      setTimeout(() => setXpToast(null), 2000);
    }

    // Progress notes or tasks counted based on quests types
    return updated;
  };

  // Google Sign-in Handler action
  const handleLoginSuccess = (enteredName: string, enteredClass: string) => {
    // Extrapolate grade and group
    const parts = enteredClass.split('/');
    const cleanGrade = parts[0] || 'ม.5';
    const cleanClassroom = parts[1] || '4';

    const newUser: User = {
      ...INITIAL_USER,
      name: enteredName,
      grade: cleanGrade,
      classroom: cleanClassroom
    };

    saveUserState(newUser);
    setStep('app');
    
    // Append welcome message
    const welcomeNotif: AppNotification = {
      id: `w_${Date.now()}`,
      title: 'ยินดีต้อนรับสู่ School Replay! 🎒',
      message: `สวัสดี ${enteredName} ระบบเชื่อมต่อรายวิชาและเควสเรียนเรียบร้อยแล้ว ได้เวลาวางแผนคว้าเกรดกันเถอะ!`,
      type: 'general',
      time: 'ตอนนี้',
      read: false
    };
    saveNotificationsState([welcomeNotif, ...notifications]);
  };

  const handleLogOut = () => {
    localStorage.removeItem('sr_user');
    setStep('landing');
    setCurrentTab('dashboard');
  };

  // Adding lesson note (auto appends relevant task if homework specified)
  const handleAddNote = (newNoteData: Omit<ReplayNote, 'id' | 'date'>) => {
    const freshId = `note_${Date.now()}`;
    const todayStr = '2026-05-23'; // Static May 23 for Thai local time simulation

    const newNote: ReplayNote = {
      ...newNoteData,
      id: freshId,
      date: todayStr
    };

    const nextNotes = [newNote, ...notes];
    saveNotesState(nextNotes);

    // Auto-Quest updates for จดสรุป 3 คาบ
    const updatedQuests = quests.map(quest => {
      if (quest.type === 'notes' && !quest.completed) {
        const nextQty = Math.min(quest.currentQuantity + 1, quest.targetQuantity);
        const done = nextQty === quest.targetQuantity;
        if (done) {
          setTimeout(() => addXp(quest.xpReward, user), 200);
        }
        return { ...quest, currentQuantity: nextQty, completed: done };
      }
      return quest;
    });
    saveQuestsState(updatedQuests);

    // Auto-create task if homework fields filled in Form
    if (newNoteData.homework) {
      const freshTaskId = `task_${Date.now()}`;
      const newTask: HomeworkTask = {
        id: freshTaskId,
        title: `${newNoteData.homework} (${newNoteData.subject})`,
        subject: newNoteData.subject,
        dueDate: newNoteData.dueDate || '2026-05-24',
        status: 'todo',
        xpReward: 90,
        noteId: freshId
      };
      
      const nextTasks = [newTask, ...tasks];
      saveTasksState(nextTasks);

      // Notify of homework creation
      const alertNotif: AppNotification = {
        id: `n_tk_${Date.now()}`,
        title: 'ตรวจพบการบ้านเพิ่มใหม่ 📌',
        message: `วิชา ${newNoteData.subject} เพิ่มการบ้านงาน: ${newNoteData.homework} ลงในปฏิทินที่รอดำเนินการเรียบร้อย`,
        type: 'task_alert',
        time: 'ตอนนี้',
        read: false
      };
      saveNotificationsState([alertNotif, ...notifications]);
    }
  };

  // Task Completion callback
  const handleToggleTaskStatus = (id: string) => {
    const updatedTasks = tasks.map(task => {
      if (task.id === id) {
        const nextStatus = task.status === 'done' ? 'todo' : 'done';
        if (nextStatus === 'done') {
          // Complete reward logic
          const updatedUser = addXp(task.xpReward, user);
          saveUserState({
            ...updatedUser,
            totalSubmittedTasks: updatedUser.totalSubmittedTasks + 1
          });

          // Increment any active task-completion quests
          const nextQuests = quests.map(q => {
            if (q.type === 'tasks' && !q.completed) {
              const nextQty = Math.min(q.currentQuantity + 1, q.targetQuantity);
              const done = nextQty === q.targetQuantity;
              if (done) {
                // Trigger quest XP as well
                setTimeout(() => addXp(q.xpReward, updatedUser), 200);
              }
              return { ...q, currentQuantity: nextQty, completed: done };
            }
            return q;
          });
          saveQuestsState(nextQuests);
        }
        return { ...task, status: nextStatus };
      }
      return task;
    });
    
    saveTasksState(updatedTasks);
  };

  const handleAddTask = (newTaskData: Omit<HomeworkTask, 'id' | 'status'>) => {
    const freshId = `task_${Date.now()}`;
    const newTask: HomeworkTask = {
      ...newTaskData,
      id: freshId,
      status: 'todo'
    };
    saveTasksState([newTask, ...tasks]);
  };

  const handleDeleteTask = (id: string) => {
    saveTasksState(tasks.filter(t => t.id !== id));
  };

  // Schedule interactions
  const handleAddSchedule = (item: Omit<ScheduleItem, 'id'>) => {
    const freshId = `sch_${Date.now()}`;
    const newItem: ScheduleItem = {
      ...item,
      id: freshId
    };
    saveSchedulesState([...schedules, newItem]);
  };

  const handleUpdateSchedule = (updated: ScheduleItem) => {
    saveSchedulesState(schedules.map(s => s.id === updated.id ? updated : s));
  };

  const handleDeleteSchedule = (id: string) => {
    saveSchedulesState(schedules.filter(s => s.id !== id));
  };

  // Quest Interactions
  const handleCompleteQuest = (id: string) => {
    const nextQuests = quests.map(q => {
      if (q.id === id) {
        const nextQty = Math.min(q.currentQuantity + 1, q.targetQuantity);
        const done = nextQty === q.targetQuantity;
        if (done) {
          addXp(q.xpReward, user);
        }
        return { ...q, currentQuantity: nextQty, completed: done };
      }
      return q;
    });
    saveQuestsState(nextQuests);
  };

  const handleResetQuests = () => {
    const reset = INITIAL_QUESTS.map(q => ({ ...q, currentQuantity: 0, completed: false }));
    saveQuestsState(reset);
  };

  // Notifications interactions
  const handleMarkNotificationRead = (id: string) => {
    saveNotificationsState(notifications.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const handleClearAllNotifications = () => {
    saveNotificationsState([]);
  };

  // Profile interaction
  const handleUpdateTimeSimulator = (hour: number, minute: number) => {
    setSimHour(hour);
    setSimMinute(minute);

    // Dynamic Alert Notification on change of simulator time
    // For example: if hour matches 8:20, append an input notification warning
    if (hour === 8 && minute === 20) {
      const classAlert: AppNotification = {
        id: `c_al_${Date.now()}`,
        title: '🚨 ติงต๊อง คาบถัดไป!',
        message: 'วิชา “คณิตศาสตร์เพิ่มเติม” กำลังจะเริ่มในอีก 10 นาที (08:30 น.) กรุณาขยับเข้าห้องเรียน 421',
        type: 'class_alert',
        time: '08:20 น.',
        read: false
      };
      
      // Prevent duplicates
      if (!notifications.some(n => n.title === classAlert.title)) {
        saveNotificationsState([classAlert, ...notifications]);
      }
    }
  };

  // Array of uniquely distinct unique subjects for ReplayNotes selector
  const subjectsList = Array.from(new Set(schedules.map(s => s.subject))).filter(Boolean) as string[];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans antialiased overflow-x-hidden">
      
      {/* Floating Level Up Celebration HUD Toast */}
      {levelUpToast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-55 w-80 bg-slate-900 border-2 border-yellow-400 text-white p-4.5 rounded-3xl shadow-2xl flex items-center gap-3 animate-bounce">
          <span className="text-3xl">🏆</span>
          <div className="space-y-0.5">
            <h5 className="font-extrabold text-xs text-yellow-400 font-display">LEVEL UP! เลเวลอัปเพิ่มพลัง</h5>
            <p className="text-[11px] text-slate-100 font-medium">{levelUpToast}</p>
          </div>
        </div>
      )}

      {/* Adding XP Toast notification pop */}
      {xpToast && (
        <div className="fixed bottom-20 right-5 z-55 bg-blue-600 text-white font-black px-4 py-2.5 rounded-2xl shadow-lg border border-blue-500 animate-scale-up flex items-center gap-1">
          <Sparkles className="w-4 h-4 fill-blue-200" />
          <span className="text-xs">+{xpToast} XP ความรู้สะสม</span>
        </div>
      )}

      {/* Render Steps */}
      {step === 'landing' && (
        <LandingPage onStart={() => setStep('login')} />
      )}

      {step === 'login' && (
        <LoginPage onLoginSuccess={handleLoginSuccess} />
      )}

      {step === 'app' && (
        <div className="flex flex-col min-h-screen pb-20 md:pb-6">
          
          {/* Main App Bar / Header */}
          <header className="bg-white/95 sticky top-0 z-40 border-b border-slate-150 py-3 px-4.5">
            <div className="max-w-md mx-auto flex items-center justify-between">
              
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-blue-500/20">
                  <GraduationCap className="w-5.5 h-5.5" />
                </div>
                <div>
                  <h1 className="font-display font-extrabold text-base text-slate-900 leading-none">School Replay</h1>
                  <span className="text-[10px] text-slate-450 font-bold whitespace-nowrap">จำแทนนักเรียน • ม.{user.grade}/{user.classroom}</span>
                </div>
              </div>

              {/* Top simulation indicators and notification flags */}
              <div className="flex items-center gap-2">
                {/* Simulated clock shortcut button */}
                <button
                  onClick={() => {
                    setCurrentTab('profile');
                    setLevelUpToast("💡 ปรับจำลองนาฬิกาเรียนของคุณที่ด้านล่างได้เลย!");
                    setTimeout(() => setLevelUpToast(null), 3000);
                  }}
                  className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 font-mono font-bold text-xs px-2.5 py-1.5 rounded-xl cursor-pointer flex items-center gap-1"
                >
                  ⏱️ {String(simHour).padStart(2, '0')}:{String(simMinute).padStart(2, '0')}
                </button>

                <button
                  onClick={() => setShowNotifPanel(true)}
                  className="relative w-8.5 h-8.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-xl flex items-center justify-center cursor-pointer"
                >
                  <Bell className="w-4 h-4" />
                  {notifications.filter(n => !n.read).length > 0 && (
                    <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full"></span>
                  )}
                </button>
              </div>

            </div>
          </header>

          {/* Desktop Responsive Navigation layout sidebar for wide viewport */}
          <div className="flex-1 max-w-md mx-auto w-full px-4 pt-5 pb-6">
            
            {/* Active page views dispatcher */}
            <main className="animate-fade-in">
              {currentTab === 'dashboard' && (
                <Dashboard
                  user={user}
                  schedules={schedules}
                  tasks={tasks}
                  quests={quests}
                  notifications={notifications}
                  timeSimulatorHour={simHour}
                  timeSimulatorMinute={simMinute}
                  onNavigate={setCurrentTab}
                  onCompleteTask={handleToggleTaskStatus}
                  onCompleteQuest={handleCompleteQuest}
                  onToggleNotificationPanel={() => setShowNotifPanel(true)}
                />
              )}

              {currentTab === 'schedule' && (
                <ScheduleView
                  schedules={schedules}
                  onAddSchedule={handleAddSchedule}
                  onUpdateSchedule={handleUpdateSchedule}
                  onDeleteSchedule={handleDeleteSchedule}
                />
              )}

              {currentTab === 'notes' && (
                <ReplayNotes
                  notes={notes}
                  subjectsList={subjectsList.length > 0 ? subjectsList : ['ชีววิทยา 3', 'เคมี 3', 'ฟิสิกส์ 3', 'คณิตศาสตร์เพิ่มเติม', 'ภาษาอังกฤษอ่านเขียน', 'ภาษาไทย 3', 'ระบบวิทย์']}
                  onAddNote={handleAddNote}
                  onDeleteNote={(id) => saveNotesState(notes.filter(n => n.id !== id))}
                  onTriggerDailySummary={() => setShowSummaryModal(true)}
                />
              )}

              {currentTab === 'tasks' && (
                <TasksView
                  tasks={tasks}
                  onAddTask={handleAddTask}
                  onToggleStatus={handleToggleTaskStatus}
                  onDeleteTask={handleDeleteTask}
                />
              )}

              {currentTab === 'quests' && (
                <QuestView
                  user={user}
                  quests={quests}
                  onCompleteQuest={handleCompleteQuest}
                  onResetQuests={handleResetQuests}
                />
              )}

              {currentTab === 'profile' && (
                <ProfileView
                  user={user}
                  onUpdateUser={saveUserState}
                  timeSimulatorHour={simHour}
                  timeSimulatorMinute={simMinute}
                  onUpdateTimeSimulator={handleUpdateTimeSimulator}
                  onLogOut={handleLogOut}
                />
              )}
            </main>

          </div>

          {/* Persistent Mobile Bottom Navigation Tabs */}
          <nav className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-md border-t border-slate-150 py-1.5 px-2.5 z-40 shadow-lg">
            <div className="max-w-md mx-auto flex items-center justify-between">
              
              {/* Dashboard Tab */}
              <button
                onClick={() => setCurrentTab('dashboard')}
                className={`flex flex-col items-center justify-center p-2 rounded-xl flex-1 cursor-pointer transition-all ${
                  currentTab === 'dashboard' ? 'text-blue-600 font-bold scale-103' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <LayoutDashboard className="w-5 h-5 mb-0.5" />
                <span className="text-[10px] tracking-tight">หน้าหลัก</span>
              </button>

              {/* Schedule Tab */}
              <button
                onClick={() => setCurrentTab('schedule')}
                className={`flex flex-col items-center justify-center p-2 rounded-xl flex-1 cursor-pointer transition-all ${
                  currentTab === 'schedule' ? 'text-blue-600 font-bold scale-103' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <Calendar className="w-5 h-5 mb-0.5" />
                <span className="text-[10px] tracking-tight">ตารางเรียน</span>
              </button>

              {/* Notes Tab */}
              <button
                onClick={() => setCurrentTab('notes')}
                className={`flex flex-col items-center justify-center p-2 rounded-xl flex-1 cursor-pointer transition-all ${
                  currentTab === 'notes' ? 'text-blue-600 font-bold scale-103' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <BookOpen className="w-5 h-5 mb-0.5" />
                <span className="text-[10px] tracking-tight">จดโน้ต</span>
              </button>

              {/* Tasks Tab */}
              <button
                onClick={() => setCurrentTab('tasks')}
                className={`flex flex-col items-center justify-center p-2 rounded-xl flex-1 cursor-pointer transition-all ${
                  currentTab === 'tasks' ? 'text-blue-600 font-bold scale-103' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <CheckSquare className="w-5 h-5 mb-0.5" />
                <span className="text-[10px] tracking-tight">การบ้าน</span>
              </button>

              {/* Quests Tab */}
              <button
                onClick={() => setCurrentTab('quests')}
                className={`flex flex-col items-center justify-center p-2 rounded-xl flex-1 cursor-pointer transition-all ${
                  currentTab === 'quests' ? 'text-blue-600 font-bold scale-103' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <Trophy className="w-5 h-5 mb-0.5" />
                <span className="text-[10px] tracking-tight">เควส</span>
              </button>

              {/* Profile Tab */}
              <button
                onClick={() => setCurrentTab('profile')}
                className={`flex flex-col items-center justify-center p-2 rounded-xl flex-1 cursor-pointer transition-all ${
                  currentTab === 'profile' ? 'text-blue-600 font-bold scale-103' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <UserIcon className="w-5 h-5 mb-0.5" />
                <span className="text-[10px] tracking-tight">โปรไฟล์</span>
              </button>

            </div>
          </nav>

          {/* Notifications lateral sheet drawer */}
          {showNotifPanel && (
            <NotificationPanel
              notifications={notifications}
              onClose={() => setShowNotifPanel(false)}
              onMarkRead={handleMarkNotificationRead}
              onClearAll={handleClearAllNotifications}
            />
          )}

          {/* End-of-Day summary modal card */}
          {showSummaryModal && (
            <DailySummaryModal
              notes={notes}
              tasks={tasks}
              onClose={() => setShowSummaryModal(false)}
              studentName={user.name}
            />
          )}

        </div>
      )}

    </div>
  );
}
