/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ReplayNote, HomeworkTask } from '../types';
import { X, Trophy, Sparkles, BookOpen, Clock, CheckCircle, Heart } from 'lucide-react';

interface DailySummaryModalProps {
  notes: ReplayNote[];
  tasks: HomeworkTask[];
  onClose: () => void;
  studentName: string;
}

export default function DailySummaryModal({
  notes,
  tasks,
  onClose,
  studentName
}: DailySummaryModalProps) {
  
  // Find notes logged today
  // Since we simulate today as 2026-05-23, let's grab the actual notes in the db
  const loggedNotesCount = notes.length;
  const pendingTasksCount = tasks.filter(t => t.status !== 'done').length;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl relative border border-slate-100 animate-scale-up">
        
        {/* Header decoration */}
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 p-6 text-white text-center relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 bg-black/10 hover:bg-black/20 text-white w-7 h-7 rounded-full flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
          
          <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-2 animate-pulse">
            <Trophy className="w-8 h-8 text-white fill-amber-300" />
          </div>

          <h3 className="text-xl font-bold font-display">สรุปการเรียนรายวันสมบูรณ์!</h3>
          <p className="text-xs text-yellow-105 font-medium mt-1">เก่งมากจ้า {studentName} คลีนตารางสุดยอด</p>
        </div>

        {/* Content detail listings */}
        <div className="p-6 space-y-5 text-xs text-slate-700">
          
          {/* Stats summary row */}
          <div className="grid grid-cols-2 gap-3.5 text-center">
            <div className="bg-amber-50 rounded-2xl p-4 border border-amber-100">
              <BookOpen className="w-5 h-5 text-amber-600 mx-auto mb-1" />
              <p className="text-[10px] text-slate-400 uppercase font-bold">บันทึกวิชาเรียน</p>
              <p className="text-sm font-extrabold text-amber-800">{loggedNotesCount} คาบจดสรุป</p>
            </div>

            <div className="bg-blue-50 rounded-2xl p-4 border border-blue-100">
              <Clock className="w-5 h-5 text-blue-600 mx-auto mb-1" />
              <p className="text-[10px] text-slate-400 uppercase font-bold">งานที่เหลืออยู่</p>
              <p className="text-sm font-extrabold text-blue-800">{pendingTasksCount} ภารกิจวิชา</p>
            </div>
          </div>

          {/* Topics learned breakdown */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-800 flex items-center gap-1">
              📝 คาบและสาระสำคัญที่สรุปวันนี้:
            </h4>
            
            {notes.length > 0 ? (
              <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                {notes.map(note => (
                  <div key={note.id} className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl space-y-1">
                    <p className="font-bold text-[11px] text-blue-700 truncate">{note.subject}</p>
                    <p className="text-[11px] font-semibold text-slate-800 truncate">เรียนเรื่อง: {note.topic}</p>
                    {note.homework && (
                      <p className="text-[10px] text-rose-600 font-semibold italic">📌 สั่งการบ้าน: {note.homework}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-slate-400 italic py-2">ยังไม่ได้จดบันทึกวิชาเรียนลง Replay Notes วันนี้เลย</p>
            )}
          </div>

          {/* Encouragement text */}
          <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-2xl flex items-start gap-3">
            <Heart className="w-5 h-5 text-emerald-500 fill-emerald-500 shrink-0 mt-0.5" />
            <p className="text-[11px] text-emerald-800 leading-relaxed font-normal">
              <strong>ข้อความให้กำลังใจ:</strong> "การทบทวนความรู้ทันทีหลังจากเลิกเรียนวันละ 10 นาที จะช่วยให้ความจำระยะยาวมีสิทธิภาพเพิ่มขึ้นกว่า 80% พักผ่อนสมองของเจ้า พรุ่งนี้มาร่วมเรียนรู้ต่อกันนะ!"
            </p>
          </div>

        </div>

        {/* Action Button */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end">
          <button
            onClick={onClose}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-6 rounded-xl transition-all shadow-xs cursor-pointer"
          >
            รับทราบและบันทึกสรุป
          </button>
        </div>

      </div>
    </div>
  );
}
