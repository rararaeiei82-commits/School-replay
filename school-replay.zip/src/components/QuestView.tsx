/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User, QuestItem } from '../types';
import { 
  Flame, Zap, Trophy, Sparkles, Star, TrendingUp, CheckCircle, Gift 
} from 'lucide-react';

interface QuestViewProps {
  user: User;
  quests: QuestItem[];
  onCompleteQuest: (id: string) => void;
  onResetQuests: () => void;
}

export default function QuestView({
  user,
  quests,
  onCompleteQuest,
  onResetQuests
}: QuestViewProps) {
  
  // XP Progress Percentage
  const xpPercent = Math.min(Math.round((user.xp / user.xpNeeded) * 100), 100);

  return (
    <div className="space-y-6">
      
      {/* Dynamic Profile Rank & Gamification Top Panel */}
      <div className="bg-slate-900 text-white rounded-3xl p-5 shadow-xl relative overflow-hidden">
        {/* Abstract design elements to avoid low quality decor */}
        <div className="absolute right-[-15px] bottom-[-15px] opacity-10">
          <Star className="w-40 h-40 text-white fill-white" />
        </div>

        <div className="space-y-5">
          {/* Level and streak badges */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-12 h-12 bg-blue-500 rounded-2xl flex items-center justify-center font-display font-extrabold text-2xl text-white shadow-md shadow-blue-500/20">
                {user.level}
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">ระดับผู้ใช้เรียน</span>
                <h3 className="text-base font-bold text-slate-100">นักเรียนระดับ: ถ้อยแถลงความขยัน</h3>
              </div>
            </div>

            {/* Streak flame */}
            <div className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/30 text-amber-500 px-3.5 py-1.5 rounded-full shadow-sm">
              <Flame className="w-4 h-4 text-amber-500 fill-amber-500 animate-pulse" />
              <span className="text-xs font-black">{user.streak} วันต่อเนื่อง</span>
            </div>
          </div>

          {/* XP Progress Slider */}
          <div className="space-y-2">
            <div className="flex items-baseline justify-between text-xs">
              <span className="text-slate-350 font-medium">ค่าประสบการณ์เรียนรู้ทั่วไป (XP)</span>
              <span className="font-extrabold text-blue-400 font-mono">{user.xp} / {user.xpNeeded} XP</span>
            </div>
            
            <div className="w-full bg-white/10 h-3 rounded-full overflow-hidden p-[2px]">
              <div 
                className="bg-gradient-to-r from-blue-500 to-sky-400 h-full rounded-full transition-all duration-700"
                style={{ width: `${xpPercent}%` }}
              ></div>
            </div>
          </div>

          {/* Quick Level up advice */}
          <p className="text-[11px] text-slate-400 font-normal leading-relaxed">
            ✏️ จดสรุปคาบเรียน และส่งการบ้านตรงเวลาเพื่อสะสมโบนัส XP สูงสุด แล้วรับแรงเลื่อนขั้นอัพเวลกันแบบฟันๆ!
          </p>
        </div>
      </div>

      {/* Quest listing header with developer debug helper */}
      <div className="flex justify-between items-center bg-white/60 p-1.5 rounded-2xl border border-slate-205 px-3">
        <div className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-500" />
          <h3 className="font-bold text-slate-800 text-sm font-display">เควสกิจกรรมรายสัปดาห์</h3>
        </div>
        
        <button
          onClick={onResetQuests}
          className="text-[11px] font-semibold text-blue-600 hover:underline cursor-pointer"
        >
          รีเซ็ตเควสใหม่
        </button>
      </div>

      {/* Actual Quests lists */}
      <div className="space-y-4">
        {quests.map(quest => {
          const isDone = quest.completed;
          return (
            <div 
              key={quest.id}
              className={`p-4.5 rounded-2xl border-2 transition-all ${
                isDone 
                  ? 'bg-emerald-50/20 border-emerald-100 opacity-80' 
                  : 'bg-white border-slate-150'
              }`}
            >
              <div className="flex items-start justify-between gap-4.5">
                <div className="space-y-1.5 flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-base text-slate-500">⭐</span>
                    <h4 className={`font-bold text-sm leading-tight tracking-tight ${isDone ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                      {quest.title}
                    </h4>
                  </div>
                  
                  {/* Progress Indicators */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] text-slate-500 font-semibold font-mono">
                      <span>ความคืบหน้า</span>
                      <span>{quest.currentQuantity} / {quest.targetQuantity} ครั้ง</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all ${isDone ? 'bg-emerald-500' : 'bg-blue-500'}`}
                        style={{ width: `${(quest.currentQuantity / quest.targetQuantity) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>

                {/* Right side interactions */}
                <div className="text-right shrink-0 flex flex-col justify-between h-full space-y-2">
                  <span className="text-[11px] font-extrabold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-lg border border-blue-100 uppercase block">
                    💎 +{quest.xpReward} XP
                  </span>
                  
                  {isDone ? (
                    <div className="text-emerald-600 text-[11px] font-bold flex items-center gap-1 justify-end pt-2">
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>ยินดีด้วย!</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => onCompleteQuest(quest.id)}
                      className="text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-1.5 rounded-xl transition-all shadow-sm cursor-pointer"
                    >
                      คืบหน้า +1
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Rewards Showcase banner */}
      <div className="bg-amber-50/50 border border-amber-100 p-4 rounded-2xl flex gap-3">
        <Gift className="w-7 h-7 text-amber-500 shrink-0 mt-0.5 animate-bounce" />
        <div className="space-y-1">
          <h4 className="font-bold text-amber-900 text-xs">โบนัสรางวัลกิจกรรมพิเศษเมื่อขึ้นแท่น Level 5</h4>
          <p className="text-xs text-amber-700 leading-relaxed font-normal">
            นักเรียนจะปลดล็อกตราสัญลักษณ์สกินธีม <strong>"นักวิชาการเหรียญทอง"</strong> และสามารถอวดผลสอบบนระบบ Cloud กับเพื่อนๆ ทั่วประเทศได้ทันที!
          </p>
        </div>
      </div>

    </div>
  );
}
