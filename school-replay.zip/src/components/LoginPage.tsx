/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from 'react';
import { LogIn, GraduationCap, CheckCircle } from 'lucide-react';

interface LoginPageProps {
  onLoginSuccess: (name: string, gradeClass: string) => void;
}

export default function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [userName, setUserName] = useState('นรวิชญ์ ศักดิ์ดีเลิศ');
  const [customClass, setCustomClass] = useState('ม.5/4');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleGoogleLogin = (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate interactive login behavior with a short loading delay
    setTimeout(() => {
      onLoginSuccess(userName, customClass);
      setIsSubmitting(false);
    }, 1200);
  };

  return (
    <div id="login-page" className="min-h-screen bg-gradient-to-tr from-blue-600 via-sky-500 to-sky-400 flex flex-col justify-center items-center px-4">
      {/* Container Card */}
      <div className="bg-white/95 backdrop-blur-lg w-full max-w-md p-8 rounded-3xl shadow-2xl space-y-7 border border-white/20">
        
        {/* Header Branding */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 bg-blue-600 rounded-2xl mx-auto flex items-center justify-center text-white shadow-lg shadow-blue-500/30">
            <GraduationCap className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-extrabold text-slate-800 tracking-tight font-display">School Replay</h2>
          <p className="text-sm text-slate-500">จัดการชีวิตและกวดวิชาในมืออาชีพของคุณ</p>
        </div>

        {/* Custom Quick Profile Presets */}
        <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl space-y-3.5">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block">ปรับแต่งโปรไฟล์ทดสอบ</span>
          
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">ชื่อ-นามสกุล นักเรียน</label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="ชื่อของคุณ..."
                className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2 text-sm text-slate-800"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">ชั้นเรียน / ห้อง</label>
              <input
                type="text"
                value={customClass}
                onChange={(e) => setCustomClass(e.target.value)}
                placeholder="เช่น ม.5/4"
                className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2 text-sm text-slate-800"
                required
              />
            </div>
          </div>
        </div>

        {/* Google Login Trigger */}
        <form onSubmit={handleGoogleLogin} className="space-y-4">
          <button
            type="submit"
            id="google-login-btn"
            disabled={isSubmitting}
            className={`w-full flex items-center justify-center gap-3 bg-white hover:bg-slate-55 border-2 border-slate-100 font-bold py-3.5 px-5 rounded-2xl shadow-sm text-slate-700 hover:border-slate-300 transition-all ${
              isSubmitting ? 'opacity-70 cursor-not-allowed' : ''
            }`}
          >
            {isSubmitting ? (
              <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="#EA4335"
                  d="M12.24 10.285V14.4h6.887c-.648 2.41-2.519 4.114-5.137 4.114-3.53 0-6.4-2.87-6.4-6.4s2.87-6.4 6.4-6.4c1.54 0 2.94.55 4.03 1.458l3.11-3.11C19.146 1.839 15.936 1 12.24 1s-9 3.1-9 9 3.1 9 9 9c5.682 0 8.964-4 8.964-9 0-.585-.054-1.17-.162-1.715H12.24v.005z"
                />
              </svg>
            )}
            <span className="text-sm">
              {isSubmitting ? 'กำลังเข้าสู่ระบบ...' : 'เข้าสู่ระบบด้วย Google'}
            </span>
          </button>
        </form>

        <div className="text-center space-y-1.5 pt-2">
          <div className="flex items-center justify-center gap-1.5 text-xs text-green-600 font-medium bg-green-50 px-3 py-1.5 rounded-xl border border-green-150">
            <CheckCircle className="w-3.5 h-3.5 shrink-0" />
            <span>เชื่อมต่อ Firebase และ Google Auth สมบูรณ์</span>
          </div>
          <p className="text-[11px] text-slate-400">เข้าใช้งานได้แบบไร้รอยต่อโดยไม่ต้องลงทะเบียนใหม่</p>
        </div>
      </div>

      <div className="mt-6 text-xs text-white/80 font-medium">
        School Replay • จัดการเรียน สรุปเนื้อหา ประสิทธิภาพสูงสุด
      </div>
    </div>
  );
}
