/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AppNotification } from '../types';
import { X, Bell, AlertCircle, Clock, Check, Sparkles } from 'lucide-react';

interface NotificationPanelProps {
  notifications: AppNotification[];
  onClose: () => void;
  onMarkRead: (id: string) => void;
  onClearAll: () => void;
}

export default function NotificationPanel({
  notifications,
  onClose,
  onMarkRead,
  onClearAll
}: NotificationPanelProps) {
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex justify-end">
      <div className="bg-white w-full max-w-sm h-full p-6 shadow-2xl flex flex-col justify-between animate-slide-left border-l border-slate-200">
        
        <div className="space-y-5 flex-1 overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-1.5">
              <Bell className="w-5 h-5 text-blue-600 animate-swing" />
              <h3 className="font-bold text-slate-800 text-base font-display">การแจ้งเตือนเรียนเรียน</h3>
            </div>
            
            <button 
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-all cursor-pointer"
            >
              <X className="w-4.5 h-4.5" />
            </button>
          </div>

          {/* Action Row */}
          {notifications.length > 0 && (
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400 font-bold uppercase">รายการข้อความทั้งหมด ({notifications.length})</span>
              <button 
                onClick={onClearAll}
                className="text-slate-500 hover:text-blue-600 font-bold hover:underline cursor-pointer"
              >
                ล้างทั้งหมด
              </button>
            </div>
          )}

          {/* Messages list */}
          <div className="space-y-3.5">
            {notifications.length > 0 ? (
              notifications.map(notif => (
                <div 
                  key={notif.id}
                  className={`p-3.5 rounded-2xl border transition-all relative ${
                    notif.read ? 'bg-slate-50 border-slate-150 opacity-75' : 'bg-blue-50/40 border-blue-100 shadow-xs'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {/* Circle icon types */}
                    <div className="shrink-0 mt-0.5">
                      {notif.type === 'class_alert' ? (
                        <Clock className="w-4.5 h-4.5 text-blue-500" />
                      ) : notif.type === 'task_alert' ? (
                        <AlertCircle className="w-4.5 h-4.5 text-rose-500" />
                      ) : (
                        <Sparkles className="w-4.5 h-4.5 text-amber-500" />
                      )}
                    </div>

                    <div className="flex-1 space-y-1">
                      <div className="flex justify-between items-baseline gap-2">
                        <h4 className={`font-bold text-xs text-slate-800 ${notif.read ? '' : 'text-blue-900'}`}>{notif.title}</h4>
                        <span className="text-[9px] font-mono text-slate-400 font-semibold shrink-0">{notif.time}</span>
                      </div>
                      <p className="text-[11px] text-slate-600 leading-relaxed font-normal">{notif.message}</p>
                    </div>
                  </div>

                  {/* Mark as read tick */}
                  {!notif.read && (
                    <button
                      onClick={() => onMarkRead(notif.id)}
                      className="absolute right-2.5 bottom-2 bg-white text-blue-600 text-[10px] hover:bg-blue-50 font-bold border border-blue-200 px-2 py-0.5 rounded-md flex items-center gap-0.5 hover:scale-105 transition-all cursor-pointer"
                    >
                      <Check className="w-3 h-3" />
                      <span>อ่านแล้ว</span>
                    </button>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center py-12 space-y-2">
                <span className="text-3xl">📭</span>
                <p className="font-bold text-slate-600 text-sm">การแจ้งเตือนว่างป่าว</p>
                <p className="text-xs text-slate-450 px-4">ระบบจัดสรรการแจ้งเตือนงานด่วนและชั่วโมงเรียนเมื่อเวลาจำลองเลื่อนอัตโนมัติ!</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer info banner */}
        <div className="pt-4 border-t border-slate-100 text-center text-[10px] text-slate-400 font-medium">
          💡 ระบบแจ้งเตือน School Replay วิเคราะห์ผลการบ้านและตารางเวลาแบบ Real-time
        </div>

      </div>
    </div>
  );
}
