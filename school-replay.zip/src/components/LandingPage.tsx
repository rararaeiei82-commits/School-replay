/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BookOpen, Calendar, CheckSquare, Award, Sparkles, LogIn, StepForward } from 'lucide-react';

interface LandingPageProps {
  onStart: () => void;
}

export default function LandingPage({ onStart }: LandingPageProps) {
  const features = [
    {
      icon: <Calendar className="w-8 h-8 text-blue-500" />,
      title: 'ตารางเรียนครบถ้วน',
      description: 'จัดการ 7 คาบเรียนต่อวัน ใส่สีวิชา ครูผู้สอน เวลา และห้องเรียนอย่างชัดเจน ไม่ลืมคาบเรียนถัดไปพักกลางวันหรือเรียนห้องไหน',
      color: 'bg-blue-50 border-blue-100'
    },
    {
      icon: <BookOpen className="w-8 h-8 text-sky-500" />,
      title: 'Replay Notes บันทึกด่วน',
      description: 'จดบันทึกเนื้อหาการเรียนประจำวัน การบ้าน วันที่กำหนดส่ง รวมถึง mock แนบถ่ายรูปสมุดบันทึกไว้ทบทวนได้ทันที',
      color: 'bg-sky-50 border-sky-100'
    },
    {
      icon: <CheckSquare className="w-8 h-8 text-indigo-500" />,
      title: 'Tasks ติดตามการส่งงาน',
      description: 'อัปเดตและแยกแยะสถานะการบ้าน ต้องทำ, ใกล้ส่ง, หรือส่งแล้ว พร้อมระบบตัวกรองวันและสัปดาห์นี้อย่างฉลาด',
      color: 'bg-indigo-50 border-indigo-100'
    },
    {
      icon: <Award className="w-8 h-8 text-purple-500" />,
      title: 'Quest ระบบพิชิตกิจกรรม',
      description: 'เปลี่ยนทุกความขยันเป็นผลลัพธ์สะสมแต้มพอยต์ XP, เก็บเลเวลเรียน, และทำสตรีคใช้งานสม่ำเสมอเพิ่มพลังกระตือรือร้น',
      color: 'bg-purple-50 border-purple-100'
    }
  ];

  return (
    <div id="landing-page" className="min-h-screen bg-slate-50 flex flex-col justify-between selection:bg-blue-200">
      {/* Navbar Minimalist */}
      <header className="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-slate-100 px-4 py-3.5">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-blue-500/20">
              <span className="font-display font-extrabold text-lg tracking-wider">SR</span>
            </div>
            <span className="font-display font-bold text-xl text-slate-800 tracking-tight">School Replay</span>
          </div>
          <button
            onClick={onStart}
            id="btn-login-header"
            className="flex items-center gap-1.5 text-xs font-semibold bg-blue-50 text-blue-600 hover:bg-blue-100 px-3.5 py-2 rounded-xl transition-all"
          >
            <LogIn className="w-3.5 h-3.5" />
            เข้าสู่ระบบ
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-md mx-auto w-full px-4 pt-8 pb-12 flex flex-col items-center">
        {/* Hero Section */}
        <div className="text-center mb-9 animate-fade-in">
          <span className="inline-flex items-center gap-1.5 bg-sky-100 text-sky-700 text-xs font-semibold px-3 py-1 rounded-full mb-3 shadow-sm">
            <Sparkles className="w-3.5 h-3.5 fill-sky-200" />
            ผู้ช่วยเรียน ม.ปลาย ส่วนตัวที่ดีที่สุด
          </span>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight leading-tight font-display mb-4">
            School <span className="text-blue-600">Replay</span>
          </h1>
          <p className="text-lg text-slate-600 font-medium mb-6">
            “จำแทนนักเรียน วางแผนเพื่อการเรียน”
          </p>
          <button
            onClick={onStart}
            id="btn-start-hero"
            className="w-full bg-gradient-to-r from-blue-600 to-sky-500 text-white font-bold py-3.5 px-6 rounded-2xl shadow-lg shadow-blue-500/20 hover:shadow-xl hover:shadow-blue-500/30 active:scale-98 transition-all flex items-center justify-center gap-2 text-base"
          >
            เริ่มใช้งานได้เลย
            <StepForward className="w-5 h-5" />
          </button>
        </div>

        {/* Feature showcase Header */}
        <div className="w-full mb-5">
          <h2 className="text-sm font-bold text-slate-400 uppercase tracking-widest text-center">ฟีเจอร์เด่นเพื่อการจัดการเรียน</h2>
        </div>

        {/* Bento/Grid style lists */}
        <div className="grid grid-cols-1 gap-4 w-full">
          {features.map((feature, idx) => (
            <div
              key={idx}
              className={`p-5 rounded-2xl border ${feature.color} flex gap-4 transition-all hover:translate-y-[-2px] hover:shadow-sm`}
            >
              <div className="shrink-0 mt-0.5">
                {feature.icon}
              </div>
              <div className="space-y-1">
                <h3 className="font-bold text-slate-800 text-base">{feature.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed font-normal">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Smart Quote decoration */}
        <div className="mt-8 bg-sky-950 text-white p-5 rounded-3xl w-full text-center space-y-2 shadow-sm relative overflow-hidden">
          <div className="absolute right-[-10px] bottom-[-10px] opacity-10 blur-[1px]">
            <Sparkles className="w-24 h-24 text-white" />
          </div>
          <p className="text-xs font-medium text-sky-300 tracking-wide uppercase">💡 คติประจำใจการเรียนวันนี้</p>
          <p className="text-sm font-semibold italic text-slate-100">
            "การเรียนรู้เปรียบเสมือนการปลูกต้นไม้ ผลของมันจะให้ร่มเงาที่ยอดเยี่ยมในวันพรุ่งนี้"
          </p>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-100 py-6 text-center text-xs text-slate-400">
        <div className="max-w-md mx-auto space-y-1">
          <p className="font-semibold text-slate-500">&copy; 2026 School Replay. All rights reserved.</p>
          <p>สร้างขึ้นเพื่อยกระดับการจัดการตารางเรียนและการเรียนรู้ของนักเรียนไทย</p>
        </div>
      </footer>
    </div>
  );
}
