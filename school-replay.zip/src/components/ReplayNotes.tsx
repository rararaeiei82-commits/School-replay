/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from 'react';
import { ReplayNote } from '../types';
import { BookOpen, Sparkles, Camera, Save, Trash2, Calendar, FileText, Check, HelpCircle } from 'lucide-react';

interface ReplayNotesProps {
  notes: ReplayNote[];
  subjectsList: string[];
  onAddNote: (note: Omit<ReplayNote, 'id' | 'date'>) => void;
  onDeleteNote: (id: string) => void;
  onTriggerDailySummary: () => void;
}

// Excellent education/science mock pictures for attachment simulation
const MOCK_ATTACHMENTS = [
  'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=600&auto=format&fit=crop', // Lab/notes
  'https://images.unsplash.com/photo-1603126857599-f6e157fa2fe6?q=80&w=600&auto=format&fit=crop', // Chemistry
  'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?q=80&w=600&auto=format&fit=crop', // Study math
  'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?q=80&w=600&auto=format&fit=crop'  // Book study
];

export default function ReplayNotes({
  notes,
  subjectsList,
  onAddNote,
  onDeleteNote,
  onTriggerDailySummary
}: ReplayNotesProps) {
  // Form states
  const [subject, setSubject] = useState(subjectsList[0] || 'ชีววิทยา 3');
  const [topic, setTopic] = useState('');
  const [content, setContent] = useState('');
  const [homework, setHomework] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isSavedAlert, setIsSavedAlert] = useState(false);

  // Quick photo simulation counter
  const [photoIndex, setPhotoIndex] = useState(0);

  const handleAttachMockPhoto = () => {
    const chosenUrl = MOCK_ATTACHMENTS[photoIndex % MOCK_ATTACHMENTS.length];
    setImageUrl(chosenUrl);
    setPhotoIndex(prev => prev + 1);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    onAddNote({
      subject,
      topic,
      content: content || 'สาระสำคัญของคาบเรียนและคีย์เวิร์ดสำหรับการทบทวนด่วน...',
      homework,
      dueDate: homework ? dueDate || '2026-05-24' : undefined,
      imageUrl: imageUrl || undefined
    });

    // Reset Form
    setTopic('');
    setContent('');
    setHomework('');
    setDueDate('');
    setImageUrl('');

    // Quick notification anim
    setIsSavedAlert(true);
    setTimeout(() => setIsSavedAlert(false), 2500);
  };

  return (
    <div className="space-y-6">
      
      {/* Page header and Recap button */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-900 font-display">สมุดจดสรุป Replay Notes</h2>
        
        <button
          onClick={onTriggerDailySummary}
          className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold px-4 py-2.5 rounded-2xl text-xs shadow-md transition-all cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-white fill-amber-200" />
          สรุปวันนี้ (AI Recap)
        </button>
      </div>

      {/* Primary Write Note form */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
        <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5 pb-2.5 border-b border-slate-100">
          <BookOpen className="w-4 h-4 text-blue-500" /> บันทึกคาบเรียนประจำวัน
        </h3>

        {isSavedAlert && (
          <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 p-3 rounded-xl text-xs font-semibold flex items-center gap-1.5 animate-bounce">
            <Check className="w-4 h-4 text-emerald-600" />
            บันทึกโน้ตคาบเรียนและสร้างการบ้านใน Tasks อัตโนมัติแล้ว!
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs font-medium">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Subject selector */}
            <div className="space-y-1">
              <label className="block text-slate-500 font-semibold mb-1 col-span-1">วิชาที่เรียน</label>
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800 text-xs"
              >
                {subjectsList.map((sub, idx) => (
                  <option key={idx} value={sub}>{sub}</option>
                ))}
                <option value="วิชาอื่นๆ">วิชาอื่นๆ / กิจกรรมอิสระ</option>
              </select>
            </div>

            {/* Topic study */}
            <div className="space-y-1">
              <label className="block text-slate-500 font-semibold mb-1">วันนี้เรียนอะไร <span className="text-rose-500">*</span></label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="หัวข้อเรียนหลัก เช่น พันธะไอออนิก, โครงสร้างเซลล์พืช"
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800 text-xs"
                required
              />
            </div>
          </div>

          {/* Details / Notes body */}
          <div className="space-y-1">
            <label className="block text-slate-500 font-semibold mb-1">จดบันทึกย่อ / สาระสำคัญ</label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="รายละเอียดสั้นๆ สิ่งที่ครูเน้นย้ำ ข้อสอบที่จะออก หรือคีย์เวิร์ดจดจำหลัก..."
              rows={3}
              className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800 text-xs leading-relaxed"
            />
          </div>

          {/* Homework and submission section */}
          <div className="bg-blue-50/50 border border-blue-100 p-4 rounded-xl space-y-3.5">
            <h4 className="font-bold text-blue-800 text-xs flex items-center gap-1.5">
              📝 การมีงานค้างหรือการบ้าน (หากมีจะอัปเดตงานและเพิ่มแต้ม XP)
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pb-1">
              <div className="space-y-1">
                <label className="block text-blue-700 text-[11px] font-semibold">ชื่องานการบ้าน</label>
                <input
                  type="text"
                  value={homework}
                  onChange={(e) => setHomework(e.target.value)}
                  placeholder="เช่น เขียนรายงานผลการทดลองชีววิทยา"
                  className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3 py-2 text-slate-800 text-xs"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-blue-700 text-[11px] font-semibold">วันกำหนดส่งงาน</label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3 py-1.5 text-slate-800 text-xs font-semibold"
                />
              </div>
            </div>
          </div>

          {/* Photo attach and save form operations */}
          <div className="flex items-center justify-between gap-4 pt-1">
            <button
              type="button"
              onClick={handleAttachMockPhoto}
              className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all border cursor-pointer ${
                imageUrl 
                  ? 'bg-emerald-50 border-emerald-100 text-emerald-700' 
                  : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <Camera className="w-4.5 h-4.5" />
              {imageUrl ? '📸 แนบรูปวิชาเรียบร้อย' : '📷 จำลองแนบรูปถ่ายกระดาน'}
            </button>

            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-6 rounded-xl flex items-center gap-1.5 shadow-sm transition-colors text-xs cursor-pointer"
            >
              <Save className="w-4 h-4 text-white" />
              บันทึกโน้ต
            </button>
          </div>

          {imageUrl && (
            <div className="p-2 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-3 animate-fade-in text-[10px]">
              <div className="flex items-center gap-2">
                <img src={imageUrl} alt="attached thumbnail" className="w-8 h-8 rounded object-cover" />
                <span className="text-slate-500 truncate max-w-[200px]">{imageUrl}</span>
              </div>
              <button 
                type="button" 
                onClick={() => setImageUrl('')}
                className="text-rose-500 hover:underline"
              >
                ลบออก
              </button>
            </div>
          )}
        </form>
      </div>

      {/* History Replay lists showcase */}
      <div className="space-y-3.5">
        <h3 className="font-bold text-slate-800 text-sm font-display">📖 บันทึกวิชาเรียนล่าสุด</h3>
        
        {notes.length > 0 ? (
          <div className="space-y-3.5">
            {notes.map(note => (
              <div 
                key={note.id} 
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs hover:border-slate-300 transition-colors"
              >
                {note.imageUrl && (
                  <div className="w-full h-36 relative bg-slate-100 overflow-hidden">
                    <img 
                      src={note.imageUrl} 
                      alt={note.topic} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                )}
                
                <div className="p-4.5 space-y-3 text-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 font-bold text-[10px] sm:text-xs">
                        {note.subject}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono font-bold">
                        📅 จดเมื่อ: {note.date}
                      </span>
                    </div>

                    <button
                      onClick={() => onDeleteNote(note.id)}
                      className="text-slate-400 hover:text-rose-600 p-1 rounded hover:bg-slate-50 transition-colors"
                      title="ลบสรุปคาบ"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-1">
                    <h4 className="font-bold text-slate-800 text-sm">{note.topic}</h4>
                    <p className="text-slate-600 leading-relaxed text-[11px] sm:text-xs">
                      {note.content}
                    </p>
                  </div>

                  {note.homework && (
                    <div className="bg-amber-50 border border-amber-100 p-3 rounded-xl flex items-start gap-2.5">
                      <span className="mt-0.5">📌</span>
                      <div className="space-y-0.5 flex-1">
                        <p className="font-bold text-amber-900 text-[11px]">การบ้าน: {note.homework}</p>
                        {note.dueDate && (
                          <p className="text-[10px] font-bold text-amber-700">🗓️ กำหนดส่ง: {note.dueDate}</p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-2xl py-10 text-center space-y-2">
            <span className="text-4xl">✒️</span>
            <p className="font-bold text-slate-700">ยังไม่มีบันทึก Replay Notes เลย</p>
            <p className="text-xs text-slate-400">เมื่อคุณเขียนสรุปวิชาเรียน ความรู้และความภูมิใจของคุณจะเซฟไว้ตรงนี้</p>
          </div>
        )}
      </div>

    </div>
  );
}
