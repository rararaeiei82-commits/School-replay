/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { User, ScheduleItem, HomeworkTask, QuestItem, AppNotification } from '../types';
import { 
  Clock, ArrowRight, AlertCircle, Trophy, Sparkles, CheckCircle2, 
  Calendar, BookOpen, ChevronRight, Bell, HelpCircle 
} from 'lucide-react';

interface DashboardProps {
  user: User;
  schedules: ScheduleItem[];
  tasks: HomeworkTask[];
  quests: QuestItem[];
  notifications: AppNotification[];
  timeSimulatorHour: number;
  timeSimulatorMinute: number;
  onNavigate: (tab: string) => void;
  onCompleteTask: (id: string) => void;
  onCompleteQuest: (id: string) => void;
  onToggleNotificationPanel: () => void;
}

export default function Dashboard({
  user,
  schedules,
  tasks,
  quests,
  notifications,
  timeSimulatorHour,
  timeSimulatorMinute,
  onNavigate,
  onCompleteTask,
  onCompleteQuest,
  onToggleNotificationPanel
}: DashboardProps) {
  
  // Custom helper to match Thailand's default week days
  const todayDayThai = 'จันทร์'; // Simulate as Monday for comprehensive 7-period schedule interaction
  
  // Get schedules for simulated day
  const todaySchedules = schedules
    .filter(s => s.day === todayDayThai)
    .sort((a,b) => a.period - b.period);

  // Time formatting
  const simTimeStr = `${String(timeSimulatorHour).padStart(2, '0')}:${String(timeSimulatorMinute).padStart(2, '0')}`;

  // Find exact active & next classes
  // Each schedule item has timeStart and timeEnd (e.g. 08:30)
  const getActiveAndNextPeriod = () => {
    let current: ScheduleItem | null = null;
    let next: ScheduleItem | null = null;

    const simMinutes = timeSimulatorHour * 60 + timeSimulatorMinute;

    for (let i = 0; i < todaySchedules.length; i++) {
      const item = todaySchedules[i];
      const [sh, sm] = item.timeStart.split(':').map(Number);
      const [eh, em] = item.timeEnd.split(':').map(Number);
      const startMin = sh * 60 + sm;
      const endMin = eh * 60 + em;

      if (simMinutes >= startMin && simMinutes < endMin) {
        current = item;
      }
      
      if (startMin > simMinutes && (!next || startMin < (Number(next.timeStart.split(':')[0]) * 60 + Number(next.timeStart.split(':')[1])))) {
        next = item;
      }
    }

    return { current, next };
  };

  const { current: currentClass, next: nextClass } = getActiveAndNextPeriod();

  // Urgent tasks (status !== 'done' and near_due)
  const urgentTasks = tasks
    .filter(t => t.status !== 'done')
    .sort((a, b) => {
      if (a.status === 'near_due' && b.status !== 'near_due') return -1;
      if (a.status !== 'near_due' && b.status === 'near_due') return 1;
      return a.dueDate.localeCompare(b.dueDate);
    })
    .slice(0, 2);

  // Today's quests progress
  const activeQuests = quests.filter(q => q.isDaily).slice(0, 3);
  
  // Daily learning hours/periods progress calculation
  // Total of 7 periods. Let's find completed periods
  const getDailyProgress = () => {
    const simMinutes = timeSimulatorHour * 60 + timeSimulatorMinute;
    if (simMinutes < 8 * 60 + 30) return 0; // Class hasn’t started
    if (simMinutes > 15 * 60 + 10) return 100; // Class ended

    let completedCount = 0;
    todaySchedules.forEach(item => {
      const [eh, em] = item.timeEnd.split(':').map(Number);
      const endMin = eh * 60 + em;
      if (simMinutes >= endMin) {
        completedCount++;
      }
    });

    // Each period is approx 14% out of 7 classes
    return Math.round((completedCount / todaySchedules.length) * 100);
  };

  const progressPercent = getDailyProgress();
  const unreadNotifCount = notifications.filter(n => !n.read).length;

  return (
    <div className="space-y-6">
      
      {/* Top Welcome Title Grid */}
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <p className="text-xs font-semibold text-slate-400">ยินดีต้อนรับกลับมา, {user.grade}/{user.classroom}</p>
          <h2 className="text-2xl font-bold text-slate-900 font-display">
            สวัสดี, <span className="text-blue-600 font-extrabold">{user.name}</span> 👋
          </h2>
        </div>
        
        {/* Simple Notification Button */}
        <button 
          onClick={onToggleNotificationPanel}
          className="relative w-10 h-10 bg-white border border-slate-200 rounded-2xl flex items-center justify-center text-slate-600 hover:text-blue-600 hover:bg-blue-50 transition-all cursor-pointer"
        >
          <Bell className="w-5 h-5" />
          {unreadNotifCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 rounded-full border-2 border-white text-[10px] font-bold text-white flex items-center justify-center animate-bounce">
              {unreadNotifCount}
            </span>
          )}
        </button>
      </div>

      {/* Daily Progress Widget Cards */}
      <div className="bg-gradient-to-br from-blue-600 to-sky-600 rounded-3xl p-5 text-white shadow-md relative overflow-hidden">
        <div className="absolute right-[-20px] top-[-20px] opacity-10">
          <Trophy className="w-32 h-32 text-white" />
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs bg-white/20 px-3 py-1 rounded-full font-semibold backdrop-blur-md">
              📅 ตารางเรียนวัน{todayDayThai} ({todaySchedules.length} คาบ)
            </span>
            <div className="flex items-center gap-1.5 text-xs text-sky-100 font-semibold bg-white/10 px-3 py-1 rounded-full">
              <Clock className="w-3.5 h-3.5" />
              <span>เรียนจำลอง: {simTimeStr} น.</span>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-baseline mb-1">
              <h3 className="text-lg font-bold">ความคืบหน้าเรียนวันนี้</h3>
              <span className="text-sm font-bold text-sky-100">{progressPercent}%</span>
            </div>
            <div className="w-full bg-white/20 h-3.5 rounded-full overflow-hidden p-0.5">
              <div 
                className="bg-white h-full rounded-full transition-all duration-500 shadow-sm"
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>
            <p className="text-xs text-blue-100 mt-1.5 font-medium">
              {progressPercent === 100 
                ? '🎉 เก่งมาก! คุณผ่านวิชาเรียนทั้งหมดในวันนี้เรียบร้อยแล้ว' 
                : `เลิกเรียนไปแล้วบางส่วน คลาสที่ผ่านพ้นวันนี้ไปดีมาก`
              }
            </p>
          </div>
        </div>
      </div>

      {/* Simulator Time Explainer Tip */}
      <div className="bg-amber-50 border border-amber-100 p-3.5 rounded-2xl flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        <p className="text-xs text-amber-800 leading-relaxed font-normal">
          <strong>ผู้เขียนสังเกต:</strong> คุณสามารถปรับแถบ <strong>"เวลาเรียนจำลอง"</strong> ได้ในเมนูโปรไฟล์หรือด้านล่างสมุด เพื่อทดสอบว่าระบบเปลี่ยนสถานะคาบถัดไปและการแจ้งเตือนอัตโนมัติได้อย่างสมจริง!
        </p>
      </div>

      {/* Next Class & Urgent Task Columns */}
      <div className="grid grid-cols-1 gap-4">
        
        {/* คาบเรียนถัดไป */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 space-y-3 shadow-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">คาบถัดไปของคุณ</span>
            <button 
              onClick={() => onNavigate('schedule')} 
              className="text-xs font-semibold text-blue-600 flex items-center gap-1 hover:underline"
            >
              ดูตารางเต็ม <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {nextClass ? (
            <div className="flex items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold text-white uppercase tracking-wider" style={{ backgroundColor: nextClass.color }}>
                  คาบ {nextClass.period}
                </span>
                <h4 className="font-bold text-slate-800 text-lg">{nextClass.subject}</h4>
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
                  <span>👨‍🏫 {nextClass.teacher}</span>
                  <span>📍 {nextClass.classroom}</span>
                </div>
              </div>
              <div className="text-right shrink-0">
                <p className="text-xs text-slate-400 font-semibold mb-1">เวลาเริ่มเข้าเรียน</p>
                <span className="bg-blue-50 text-blue-700 font-display font-bold text-base px-3 py-1.5 rounded-xl border border-blue-100 block">
                  {nextClass.timeStart} น.
                </span>
              </div>
            </div>
          ) : (
            <div className="text-center py-4 space-y-1">
              <span className="text-2xl">😎</span>
              <p className="text-sm font-semibold text-slate-600">ชั่วโมงเรียนวันนี้หมดลงแล้ว!</p>
              <p className="text-xs text-slate-400">พักพ่อนสมองตามอัธยาศัยและกลับมาฟิตต่อวันพรุ่งนี้</p>
            </div>
          )}

          {currentClass && (
            <div className="mt-2 bg-emerald-50 border border-emerald-100 p-2.5 rounded-xl flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-emerald-800 font-semibold">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span>
                <span>ขณะนี้กำลังเรียน: {currentClass.subject}</span>
              </div>
              <span className="text-[11px] text-emerald-600 font-semibold">ห้อง {currentClass.classroom}</span>
            </div>
          )}
        </div>

        {/* งานด่วน / การบ้าน */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4.5 space-y-3.5 shadow-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">งานด่วน / กำหนดส่งงาน</span>
            <button 
              onClick={() => onNavigate('tasks')} 
              className="text-xs font-semibold text-blue-600 flex items-center gap-1 hover:underline"
            >
              ดูการบ้านทั้งหมด <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {urgentTasks.length > 0 ? (
            <div className="space-y-3">
              {urgentTasks.map(task => (
                <div 
                  key={task.id} 
                  className={`p-3.5 rounded-xl border flex items-start gap-3 transition-colors ${
                    task.status === 'near_due' ? 'bg-rose-50/50 border-rose-100' : 'bg-slate-50 border-slate-100'
                  }`}
                >
                  <AlertCircle className={`w-4.5 h-4.5 shrink-0 mt-0.5 ${task.status === 'near_due' ? 'text-rose-500' : 'text-slate-400'}`} />
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-200/80 text-slate-600 truncate max-w-[120px]">
                        {task.subject}
                      </span>
                      <span className="text-[11px] font-semibold text-rose-600">
                        🚨 กำหนดส่ง {task.dueDate === '2026-05-24' ? 'พรุ่งนี้' : task.dueDate}
                      </span>
                    </div>
                    <p className="font-bold text-slate-800 text-sm truncate">{task.title}</p>
                    <div className="flex items-center justify-between pt-1">
                      <span className="text-xs text-emerald-600 font-semibold">🎁 XP รางวัล: +{task.xpReward}</span>
                      <button 
                        onClick={() => onCompleteTask(task.id)}
                        className="text-xs font-bold bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        กดส่งงานที่นี่
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-5 space-y-1.5">
              <span className="text-2xl">🙌</span>
              <p className="text-sm font-semibold text-slate-600">ไม่มีงานค้างส่งเลยในขณะนี้!</p>
              <p className="text-xs text-slate-400">คุณรักษาตารางชีทชีตไว้อย่างมืออาชีพมาก</p>
            </div>
          )}
        </div>

      </div>

      {/* Daily Quests Summary */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4.5 space-y-3 shadow-xs">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-1.5">
            <Trophy className="w-4.5 h-4.5 text-amber-500" />
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">เควส & ความขยันวันนี้</span>
          </div>
          <button 
            onClick={() => onNavigate('quests')} 
            className="text-xs font-semibold text-blue-600 flex items-center gap-1 hover:underline"
          >
            ท้าทายเพิ่ม <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {activeQuests.map(quest => (
            <div key={quest.id} className="p-3 bg-slate-50 border border-slate-100 rounded-xl space-y-2">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span>⭐</span>
                  <p className="text-xs font-bold text-slate-800">{quest.title}</p>
                </div>
                {quest.completed ? (
                  <span className="bg-emerald-100 text-emerald-800 text-[10px] uppercase font-extrabold px-2 py-0.5 rounded">สำเร็จแล้ว</span>
                ) : (
                  <span className="text-[11px] font-bold text-slate-500">{quest.currentQuantity}/{quest.targetQuantity} ครั้ง</span>
                )}
              </div>
              
              {!quest.completed && (
                <div className="space-y-1">
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-blue-500 h-full rounded-full transition-all"
                      style={{ width: `${(quest.currentQuantity / quest.targetQuantity) * 100}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-slate-400">รางวัล XP: +{quest.xpReward}</span>
                    <button 
                      onClick={() => onCompleteQuest(quest.id)}
                      className="text-blue-600 font-bold hover:underline"
                    >
                      เพิ่มเป้าหมายสำเร็จ
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
