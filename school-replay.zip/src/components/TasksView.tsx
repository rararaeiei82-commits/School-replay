/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from 'react';
import { HomeworkTask } from '../types';
import { 
  CheckCircle2, Circle, Calendar, Filter, Clock, 
  ClipboardList, Plus, Trash2, Sparkles, AlertTriangle 
} from 'lucide-react';

interface TasksViewProps {
  tasks: HomeworkTask[];
  onAddTask: (task: Omit<HomeworkTask, 'id' | 'status'>) => void;
  onToggleStatus: (id: string) => void;
  onDeleteTask: (id: string) => void;
}

type FilterType = 'today' | 'week' | 'all';

export default function TasksView({
  tasks,
  onAddTask,
  onToggleStatus,
  onDeleteTask
}: TasksViewProps) {
  const [filter, setFilter] = useState<FilterType>('all');
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('คณิตศาสตร์เพิ่มเติม');
  const [dueDate, setDueDate] = useState('');
  const [xpReward, setXpReward] = useState(80);

  // Simulated date calculations helper
  const isToday = (dateStr: string) => {
    // Simulated "today" is May 23, 2026 based on metadata
    return dateStr === '2026-05-23';
  };

  const isThisWeek = (dateStr: string) => {
    // May 23, 2026 is Saturday. Let's assume dates within +/- 4 days of May 23 are within "this week"
    const targetDate = new Date(dateStr);
    const pivotDate = new Date('2026-05-23');
    const diffTime = Math.abs(targetDate.getTime() - pivotDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 7;
  };

  const getFilteredTasks = () => {
    return tasks.filter(task => {
      if (filter === 'today') {
        return isToday(task.dueDate);
      }
      if (filter === 'week') {
        return isThisWeek(task.dueDate);
      }
      return true; // all
    });
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onAddTask({
      title,
      subject,
      dueDate: dueDate || '2026-05-24',
      xpReward
    });

    setTitle('');
    setDueDate('');
    setShowAddForm(false);
  };

  const filteredTasks = getFilteredTasks();

  // Tasks counts helper
  const todoCount = tasks.filter(t => t.status === 'todo').length;
  const nearDueCount = tasks.filter(t => t.status === 'near_due').length;
  const doneCount = tasks.filter(t => t.status === 'done').length;

  return (
    <div className="space-y-6">
      
      {/* Upper overview counts widgets */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-blue-50/70 border border-blue-100 p-3.5 rounded-2xl text-center space-y-1">
          <span className="text-xl">📋</span>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">ต้องทำ</p>
          <p className="text-base font-extrabold text-blue-700">{todoCount}</p>
        </div>

        <div className="bg-rose-50/70 border border-rose-100 p-3.5 rounded-2xl text-center space-y-1">
          <span className="text-xl">⚠️</span>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">ใกล้ส่ง</p>
          <p className="text-base font-extrabold text-rose-700">{nearDueCount}</p>
        </div>

        <div className="bg-emerald-50/70 border border-emerald-100 p-3.5 rounded-2xl text-center space-y-1">
          <span className="text-xl">🎉</span>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">ส่งแล้ว</p>
          <p className="text-base font-extrabold text-emerald-700">{doneCount}</p>
        </div>
      </div>

      {/* Primary Actions and Filter buttons */}
      <div className="bg-white border border-slate-200 p-3 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
        {/* Filters */}
        <div className="flex bg-slate-100 p-1 rounded-xl w-full sm:w-auto">
          <button
            onClick={() => setFilter('today')}
            className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filter === 'today' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            วันนี้
          </button>
          <button
            onClick={() => setFilter('week')}
            className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filter === 'week' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            สัปดาห์นี้
          </button>
          <button
            onClick={() => setFilter('all')}
            className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filter === 'all' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            ทั้งหมด
          </button>
        </div>

        {/* Quick add toggle */}
        <button
          onClick={() => setShowAddForm(prev => !prev)}
          className="w-full sm:w-auto flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4 text-white" />
          {showAddForm ? 'ปิดฟอร์ม' : 'เพิ่มการบ้านด่วน'}
        </button>
      </div>

      {/* Add Homework form element */}
      {showAddForm && (
        <div className="bg-white border-2 border-slate-250 p-5 rounded-2xl space-y-4 animate-scale-up shadow-sm">
          <h3 className="font-bold text-sm text-slate-800 flex items-center gap-1.5 pb-2 border-b border-slate-100">
            ➕ เพิ่มการบ้านใหม่
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4 text-xs font-medium">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="block text-slate-500 font-semibold mb-1">ชื่องานการบ้าน <span className="text-rose-500">*</span></label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="เช่น ทำแบบฝึกหัดแคลคูลัส 10 ข้อ"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-500 font-semibold mb-1">วิชาที่เกี่ยวข้อง</label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3 py-2.5 text-slate-800 text-xs"
                >
                  <option value="คณิตศาสตร์เพิ่มเติม">คณิตศาสตร์เพิ่มเติม</option>
                  <option value="เคมี 3">เคมี 3</option>
                  <option value="ชีววิทยา 3">ชีววิทยา 3</option>
                  <option value="ฟิสิกส์ 3">ฟิสิกส์ 3</option>
                  <option value="ภาษาอังกฤษอ่านเขียน">ภาษาอังกฤษอ่านเขียน</option>
                  <option value="ภาษาไทย 3">ภาษาไทย 3</option>
                  <option value="วิทยาการคำนวณ">วิทยาการคำนวณ</option>
                  <option value="วิชาอื่นๆ">วิชาอื่นๆ</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="block text-slate-500 font-semibold mb-1">กำหนดส่งการบ้าน</label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800 text-xs font-semibold"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-500 font-semibold mb-1">คะแนนประสบการณ์ (XP)</label>
                <input
                  type="number"
                  value={xpReward}
                  onChange={(e) => setXpReward(Number(e.target.value))}
                  placeholder="เช่น 80, 100"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-5 rounded-2xl flex items-center justify-center gap-2 text-xs cursor-pointer shadow-sm"
            >
              <Sparkles className="w-4.5 h-4.5 fill-blue-300 text-white" />
              เพิ่มและเริ่มเควส
            </button>
          </form>
        </div>
      )}

      {/* Homework Interactive list */}
      <div className="space-y-3">
        {filteredTasks.length > 0 ? (
          filteredTasks.map(task => {
            const isDone = task.status === 'done';
            return (
              <div 
                key={task.id} 
                className={`p-4 rounded-2xl border flex items-start gap-3.5 transition-all hover:shadow-xs shadow-slate-100 ${
                  isDone 
                    ? 'bg-emerald-50/20 border-emerald-100 opacity-80' 
                    : task.status === 'near_due'
                      ? 'bg-rose-50/30 border-rose-100'
                      : 'bg-white border-slate-200'
                }`}
              >
                {/* Complete / Uncomplete toggle button */}
                <button
                  onClick={() => onToggleStatus(task.id)}
                  className="mt-0.5 shrink-0 focus:outline-none text-slate-400 hover:text-blue-600 transition-colors cursor-pointer"
                >
                  {isDone ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-500 fill-emerald-100" />
                  ) : (
                    <Circle className={`w-6 h-6 ${task.status === 'near_due' ? 'text-rose-400' : 'text-slate-350'}`} />
                  )}
                </button>

                {/* Task Details */}
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded truncate max-w-[130px]">
                      {task.subject}
                    </span>
                    
                    {/* Dynamic statuses layout */}
                    <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded ${
                      task.status === 'done'
                        ? 'bg-emerald-100 text-emerald-800'
                        : task.status === 'near_due'
                          ? 'bg-rose-100 text-rose-800 animate-pulse'
                          : 'bg-indigo-100 text-indigo-800'
                    }`}>
                      {task.status === 'done' ? 'ส่งแล้ว' : task.status === 'near_due' ? 'ใกล้ส่ง' : 'ต้องทำ'}
                    </span>
                  </div>

                  <p className={`font-bold text-sm tracking-tight ${isDone ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                    {task.title}
                  </p>

                  <div className="flex items-center justify-between text-xs pt-1">
                    <div className="flex items-center gap-1.5 text-slate-450 font-medium">
                      <Calendar className="w-3.5 h-3.5" />
                      <span className={`${task.status === 'near_due' && !isDone ? 'text-rose-600 font-bold' : ''}`}>
                        ส่ง {task.dueDate === '2026-05-23' ? 'วันนี้' : task.dueDate === '2026-05-24' ? 'พรุ่งนี้' : task.dueDate}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-emerald-600 font-bold">💎 +{task.xpReward} XP</span>
                      <button
                        onClick={() => onDeleteTask(task.id)}
                        className="text-slate-400 hover:text-rose-600 p-1"
                        title="ลบงาน"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>

              </div>
            );
          })
        ) : (
          <div className="bg-white border border-slate-200 rounded-2xl py-12 text-center space-y-2">
            <div className="text-4xl text-slate-300">🎉</div>
            <p className="font-bold text-slate-700">ไม่มีภารกิจค้างอยู่ในเป้าหมายนี้</p>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">ยินดีด้วย! คุณเคลียร์การบ้านทั้งหมดเรียบร้อยแล้ว หรือสามารถสลับตัวกรองที่ด่านบนได้</p>
          </div>
        )}
      </div>

    </div>
  );
}
