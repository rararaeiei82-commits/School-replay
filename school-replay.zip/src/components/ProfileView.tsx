/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from 'react';
import { User } from '../types';
import { 
  User as UserIcon, Award, CheckSquare, Save, Edit3, 
  Clock, BookOpen, LogOut, CheckCircle2 
} from 'lucide-react';

interface ProfileViewProps {
  user: User;
  onUpdateUser: (updatedUser: User) => void;
  timeSimulatorHour: number;
  timeSimulatorMinute: number;
  onUpdateTimeSimulator: (hour: number, minute: number) => void;
  onLogOut: () => void;
}

export default function ProfileView({
  user,
  onUpdateUser,
  timeSimulatorHour,
  timeSimulatorMinute,
  onUpdateTimeSimulator,
  onLogOut
}: ProfileViewProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [grade, setGrade] = useState(user.grade);
  const [classroom, setClassroom] = useState(user.classroom);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = (e: FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      ...user,
      name,
      grade,
      classroom
    });
    setIsEditing(false);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  // Convert time to string format
  const formattedMinutes = String(timeSimulatorMinute).padStart(2, '0');
  const formattedHours = String(timeSimulatorHour).padStart(2, '0');

  return (
    <div className="space-y-6">
      
      {/* Visual Student ID Card design */}
      <div className="bg-gradient-to-tr from-sky-950 to-blue-900 text-white rounded-3xl p-6.5 shadow-xl relative overflow-hidden border border-white/10">
        
        {/* Card watermark/lines */}
        <div className="absolute right-[-40px] top-[-30px] w-48 h-48 bg-blue-500/10 rounded-full blur-2xl"></div>

        <div className="space-y-5">
          {/* Card Header branding */}
          <div className="flex justify-between items-center pb-3 border-b border-white/10 text-xs text-sky-200 uppercase tracking-widest font-bold">
            <span>บัตรประจำตัวนักเรียนดิจิตอล</span>
            <span>School Replay ID Card</span>
          </div>

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 pb-2">
            {/* Avatar block with badge indicator */}
            <div className="relative shrink-0">
              <img 
                src={user.avatarUrl || 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&h=150'} 
                alt="Student portrait" 
                className="w-20 h-20 rounded-2xl border-2 border-sky-400 object-cover shadow-md"
                referrerPolicy="no-referrer"
              />
              <span className="absolute -bottom-2 -right-2 bg-yellow-400 text-slate-900 border-2 border-blue-900 rounded-full px-2 py-0.5 text-[9px] font-black uppercase tracking-wider">
                Lv. {user.level}
              </span>
            </div>

            {/* Student particulars fields */}
            <div className="text-center sm:text-left space-y-1">
              <h3 className="font-bold text-lg font-display tracking-tight">{user.name}</h3>
              <p className="text-xs text-sky-200">นักเรียนระดับห้องเรียน: {user.grade}/{user.classroom}</p>
              <p className="text-[10px] text-slate-300 font-mono">{user.email}</p>
              
              <div className="pt-2 flex flex-wrap gap-2 justify-center sm:justify-start">
                <span className="text-[10px] bg-sky-500/20 text-sky-200 px-2.5 py-0.5 rounded-md font-semibold border border-sky-500/20">
                  ⚡ พลังสตรีคเช็กอิน {user.streak} วัน
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-200 px-2.5 py-0.5 rounded-md font-semibold border border-emerald-500/20">
                  🏆 เควส {user.questScore} แต้ม
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {isSaved && (
        <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 p-3.5 rounded-2xl text-xs font-semibold flex items-center gap-1.5 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          อัปเดตข้อมูลโปรไฟล์และตารางเรียนเรียบร้อยแล้ว!
        </div>
      )}

      {/* Edit Form Panel */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
        <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
          <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
            <UserIcon className="w-4 h-4 text-blue-500" /> ข้อมูลประวัตินักเรียน
          </h3>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="text-xs font-semibold text-blue-600 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5" />
            {isEditing ? 'ยกเลิก' : 'แก้ไขประวัติ'}
          </button>
        </div>

        {isEditing ? (
          <form onSubmit={handleSave} className="space-y-4 text-xs font-semibold">
            <div className="space-y-1">
              <label className="block text-slate-500">ชื่อ - นามสกุล</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800 text-xs"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-slate-500">ระดับชั้น (เช่น ม.5)</label>
                <input
                  type="text"
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800 text-xs"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="block text-slate-500">ห้อง (เช่น 5/4)</label>
                <input
                  type="text"
                  value={classroom}
                  onChange={(e) => setClassroom(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800 text-xs"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-4 rounded-xl flex items-center justify-center gap-1.5 transition-colors text-xs cursor-pointer shadow-sm"
            >
              <Save className="w-4 h-4" />
              บันทึกข้อมูลหลัก
            </button>
          </form>
        ) : (
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="bg-slate-50 p-3 rounded-xl space-y-0.5">
              <p className="text-slate-400 font-semibold uppercase">จำนวนการบ้านที่ส่ง</p>
              <p className="text-lg font-black text-slate-800">{user.totalSubmittedTasks} งานสำเร็จ</p>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl space-y-0.5">
              <p className="text-slate-400 font-semibold uppercase">คะแนนเควสรวม</p>
              <p className="text-lg font-black text-slate-800">{user.questScore} แต้มพอยต์</p>
            </div>
          </div>
        )}
      </div>

      {/* Time simulator widget for full interactive testing of class timings */}
      <div className="bg-amber-55/60 border-2 border-amber-100 rounded-3xl p-5 space-y-3 shadow-xs">
        <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5 pb-2 border-b border-amber-200">
          <Clock className="w-4.5 h-4.5 text-amber-500" />
          จำลองเวลาเรียนของนักเรียนวันนี้
        </h4>
        <p className="text-[11px] text-slate-600 leading-relaxed">
          เนื่องจากเป็นระบบซิมูเลเตอร์ คุณสามารถปรับเวลาจำลองเพื่อเช็กระบบการเตือนก่อนเรียน 10 นาที การเปลี่ยนคาบถัดไป และการเคลียร์วิชาเรียนโดยอัตโนมัติ!
        </p>

        <div className="space-y-3 pt-1">
          <div className="flex justify-between font-mono font-bold text-xs text-amber-900">
            <span>🕘 เลื่อนเปลี่ยนชั่วโมงเรียน:</span>
            <span className="text-slate-900 font-black text-sm bg-white px-2.5 py-1 rounded-lg border border-amber-300">
              {formattedHours}:{formattedMinutes} น.
            </span>
          </div>

          <div className="space-y-2">
            <div>
              <span className="text-[10px] text-slate-500 font-bold">ชั่วโมง: {timeSimulatorHour} น.</span>
              <input
                type="range"
                min={7}
                max={17}
                value={timeSimulatorHour}
                onChange={(e) => onUpdateTimeSimulator(Number(e.target.value), timeSimulatorMinute)}
                className="w-full accent-blue-600 cursor-pointer"
              />
            </div>

            <div>
              <span className="text-[10px] text-slate-500 font-bold">นาที: {timeSimulatorMinute} นาที</span>
              <input
                type="range"
                min={0}
                max={59}
                value={timeSimulatorMinute}
                onChange={(e) => onUpdateTimeSimulator(timeSimulatorHour, Number(e.target.value))}
                className="w-full accent-blue-600 cursor-pointer"
              />
            </div>
          </div>

          <div className="flex gap-1.5 flex-wrap pt-1">
            <button 
              onClick={() => onUpdateTimeSimulator(8, 20)}
              className="bg-white border text-slate-700 text-[10px] font-bold px-2.5 py-1.5 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            >
              8:20 น. (เช้าก่อนเริ่มคาบ 1)
            </button>
            <button 
              onClick={() => onUpdateTimeSimulator(10, 30)}
              className="bg-white border text-slate-700 text-[10px] font-bold px-2.5 py-1.5 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            >
              10:30 น. (ระหว่างวันคาบ 3-4)
            </button>
            <button 
              onClick={() => onUpdateTimeSimulator(15, 15)}
              className="bg-white border text-slate-700 text-[10px] font-bold px-2.5 py-1.5 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            >
              15:15 น. (เลิกเรียน / สรุปความรู้)
            </button>
          </div>
        </div>
      </div>

      {/* Safety Sign-out */}
      <button
        onClick={onLogOut}
        className="w-full py-3 border border-rose-200 text-rose-600 bg-rose-50/50 rounded-2xl text-xs font-bold hover:bg-rose-100 hover:text-rose-700 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
      >
        <LogOut className="w-4 h-4" />
        ออกจากระบบของ School Replay
      </button>

    </div>
  );
}
