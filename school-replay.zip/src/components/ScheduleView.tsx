/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from 'react';
import { ScheduleItem } from '../types';
import { Plus, Trash2, Edit3, Save, X, Clock, HelpCircle } from 'lucide-react';

interface ScheduleViewProps {
  schedules: ScheduleItem[];
  onAddSchedule: (item: Omit<ScheduleItem, 'id'>) => void;
  onUpdateSchedule: (item: ScheduleItem) => void;
  onDeleteSchedule: (id: string) => void;
}

const DAYS_OF_WEEK = ['จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์'];
const PERIOD_TIERS = [
  { p: 1, time: '08:30 - 09:20' },
  { p: 2, time: '09:20 - 10:10' },
  { p: 3, time: '10:10 - 11:00' },
  { p: 4, time: '11:00 - 11:50' },
  { p: 5, time: '12:40 - 13:30' },
  { p: 6, time: '13:30 - 14:20' },
  { p: 7, time: '14:20 - 15:10' }
];

const PRESET_COLORS = [
  '#3b82f6', // Blue
  '#0ea5e9', // Sky Blue
  '#10b981', // Green
  '#ec4899', // Pink
  '#8b5cf6', // Purple
  '#f59e0b', // Orange
  '#ec4899', // Hot Pink
  '#14b8a6', // Teal
  '#ef4444'  // Red
];

export default function ScheduleView({
  schedules,
  onAddSchedule,
  onUpdateSchedule,
  onDeleteSchedule
}: ScheduleViewProps) {
  const [selectedDay, setSelectedDay] = useState('จันทร์');
  const [showEditor, setShowEditor] = useState(false);
  const [editingItem, setEditingItem] = useState<ScheduleItem | null>(null);

  // Form states
  const [subject, setSubject] = useState('');
  const [teacher, setTeacher] = useState('');
  const [period, setPeriod] = useState(1);
  const [timeStart, setTimeStart] = useState('08:30');
  const [timeEnd, setTimeEnd] = useState('09:20');
  const [classroom, setClassroom] = useState('');
  const [color, setColor] = useState('#3b82f6');

  const openAddForm = () => {
    setEditingItem(null);
    setSubject('');
    setTeacher('');
    setPeriod(1);
    setTimeStart('08:30');
    setTimeEnd('09:20');
    setClassroom('');
    setColor('#3b82f6');
    setShowEditor(true);
  };

  const openEditForm = (item: ScheduleItem) => {
    setEditingItem(item);
    setSubject(item.subject);
    setTeacher(item.teacher);
    setPeriod(item.period);
    setTimeStart(item.timeStart);
    setTimeEnd(item.timeEnd);
    setClassroom(item.classroom);
    setColor(item.color);
    setShowEditor(true);
  };

  const handlePeriodChange = (pNum: number) => {
    setPeriod(pNum);
    const tier = PERIOD_TIERS.find(t => t.p === pNum);
    if (tier) {
      const [start, end] = tier.time.split(' - ');
      setTimeStart(start);
      setTimeEnd(end);
    }
  };

  const handleSave = (e: FormEvent) => {
    e.preventDefault();
    if (!subject.trim()) return;

    if (editingItem) {
      onUpdateSchedule({
        ...editingItem,
        day: selectedDay,
        period,
        subject,
        teacher,
        timeStart,
        timeEnd,
        classroom,
        color
      });
    } else {
      onAddSchedule({
        day: selectedDay,
        period,
        subject,
        teacher,
        timeStart,
        timeEnd,
        classroom,
        color
      });
    }

    setShowEditor(false);
  };

  // Filter schedules for active day, sorted by period
  const daySchedules = schedules
    .filter(s => s.day === selectedDay)
    .sort((a, b) => a.period - b.period);

  return (
    <div className="space-y-5">
      {/* Top action header */}
      <div className="flex justify-between items-center bg-white/60 p-1 rounded-2xl border border-slate-250">
        <h2 className="text-xl font-bold font-display pl-3">ตารางเรียนรายสัปดาห์</h2>
        <button
          onClick={openAddForm}
          className="flex items-center gap-1.5 bg-blue-600 text-white hover:bg-blue-700 font-semibold px-4 py-2.5 rounded-xl text-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4 text-white" />
          เพิ่มคาบเรียน
        </button>
      </div>

      {/* Days Tabs container */}
      <div className="flex gap-1.5 overflow-x-auto pb-1.5 scrollbar-thin">
        {DAYS_OF_WEEK.map(day => (
          <button
            key={day}
            onClick={() => setSelectedDay(day)}
            className={`px-4.5 py-2.5 rounded-xl font-semibold text-xs whitespace-nowrap transition-all flex-1 text-center cursor-pointer ${
              selectedDay === day
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            วัน{day}
          </button>
        ))}
      </div>

      {/* Editor Modal Overlay */}
      {showEditor && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md p-6 rounded-3xl space-y-5 shadow-2xl animate-scale-up max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-800 text-lg">
                {editingItem ? '✏️ แก้ไขข้อมูลเรียน' : '➕ เพิ่มคาบเรียนใหม่'} (วัน{selectedDay})
              </h3>
              <button 
                onClick={() => setShowEditor(false)}
                className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-all cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4 text-sm">
              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-500">ชื่อรายวิชา <span className="text-rose-500">*</span></label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="เช่น ฟิสิกส์ 3, ภาษาอังกฤษ"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-500">ครูผู้สอน</label>
                <input
                  type="text"
                  value={teacher}
                  onChange={(e) => setTeacher(e.target.value)}
                  placeholder="เช่น ครูวิมล แสนดี"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-semibold text-slate-500">คาบเรียนที่ <span className="text-rose-500">*</span></label>
                  <select
                    value={period}
                    onChange={(e) => handlePeriodChange(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3 py-2.5 text-slate-800"
                  >
                    {[1, 2, 3, 4, 5, 6, 7].map(num => (
                      <option key={num} value={num}>คาบเรียนที่ {num}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-semibold text-slate-500">ห้องเรียน</label>
                  <input
                    type="text"
                    value={classroom}
                    onChange={(e) => setClassroom(e.target.value)}
                    placeholder="เช่น ห้อง 421"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-semibold text-slate-500">เวลาเริ่ม</label>
                  <input
                    type="text"
                    value={timeStart}
                    onChange={(e) => setTimeStart(e.target.value)}
                    placeholder="08:30"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800 text-center font-mono font-medium"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-semibold text-slate-500">เวลาเลิก</label>
                  <input
                    type="text"
                    value={timeEnd}
                    onChange={(e) => setTimeEnd(e.target.value)}
                    placeholder="09:20"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:outline-none rounded-xl px-3.5 py-2.5 text-slate-800 text-center font-mono font-medium"
                  />
                </div>
              </div>

              {/* Theme Color selectors */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-500">เลือกสีประจำวิชา</label>
                <div className="flex flex-wrap gap-2.5">
                  {PRESET_COLORS.map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className={`w-7 h-7 rounded-lg border-2 transition-all flex items-center justify-center shrink-0 cursor-pointer ${
                        color === c ? 'border-slate-800 scale-110 shadow-sm' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: c }}
                    >
                      {color === c && <span className="text-white text-[10px]">✓</span>}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-5 rounded-2xl flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all text-xs"
              >
                <Save className="w-4 h-4" />
                บันทึกการเปลี่ยนแปลง
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Week list container */}
      <div className="space-y-3.5">
        {daySchedules.length > 0 ? (
          daySchedules.map(item => (
            <div
              key={item.id}
              className="bg-white border border-slate-200 rounded-2xl p-4.5 flex gap-4 shadow-xs hover:border-blue-200 hover:shadow-sm transition-all"
            >
              {/* Vertical Color Accent tab indicator */}
              <div className="w-1.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />

              <div className="flex-1 min-w-0 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded uppercase font-mono tracking-wider">
                    คาบที่ {item.period}
                  </span>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => openEditForm(item)}
                      className="p-1.5 bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-blue-600 rounded-lg border border-slate-100 transition-colors"
                      title="แก้ไข"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDeleteSchedule(item.id)}
                      className="p-1.5 bg-rose-50 hover:bg-rose-100 text-slate-600 hover:text-rose-600 rounded-lg border border-slate-100 transition-colors"
                      title="ลบ"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <h3 className="font-bold text-slate-800 text-base truncate">{item.subject}</h3>

                <div className="flex flex-wrap text-xs text-slate-500 gap-x-4 gap-y-1 font-medium">
                  <span className="flex items-center gap-1">📍 {item.classroom || 'ไม่ระบุห้องเรียน'}</span>
                  <span className="flex items-center gap-1">👨‍🏫 {item.teacher || 'ไม่ระบุครู'}</span>
                  <span className="flex items-center gap-1 text-slate-400 font-mono font-semibold">
                    <Clock className="w-3 h-3" /> {item.timeStart} - {item.timeEnd}
                  </span>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="bg-white border border-dashed border-slate-300 rounded-2xl py-12 text-center space-y-2">
            <div className="text-4xl text-slate-350">🏖️</div>
            <p className="font-bold text-slate-700">ไม่มีคาบเรียนที่กวดวิชาในวัน{selectedDay}</p>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">วัน{selectedDay} อาจเป็นวันหยุดหรือยังไม่ได้สร้าง ตารางของคุณยังว่าง สามารถกดเพิ่มคาบเรียนได้ทันที</p>
          </div>
        )}
      </div>

      <div className="bg-sky-50 border border-sky-100 p-4 rounded-2xl space-y-1">
        <h4 className="text-xs font-bold text-sky-800 tracking-wide uppercase">💡 คำแนะนำเสริมวิชาเรียน</h4>
        <p className="text-xs text-sky-700 leading-relaxed font-normal">
          ระบบตารางเรียนสูงสุดจัดสรรได้ 7 คาบต่อวันตามเวลามาตรฐานของโรงเรียนมัธยมไทย เริ่มตั้งแต่ 08:30 น. จนถึง 15:10 น.
        </p>
      </div>
    </div>
  );
}
